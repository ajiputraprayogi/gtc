@extends('layouts.base')
@section('content')

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Get The Cash</a></li>
                        <li class="breadcrumb-item active">View Transaksi GTC</li>
                    </ol>
                </div>
                <h4 class="page-title">Transaksi Data GTC</h4>
            </div>
        </div>
    </div>
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card d-block">
                <div class="card-header bg-secondary border-danger border-3" >
                    <div class=" align-items-center mb-2 text-white">
                        <h3>Transaksi GTC</h3>
                    </div>
                </div>
                @foreach($data as $row)
                <div class="card-body">
                    <input type="hidden" name="id_pengajuan" id="id_pengajuan" value="{{$row->idp}}" class="form-control">
                    <div class="row mb-2">
                        <div class="col-4">
                            <a class="btn btn-success mb-2"><i class="mdi mdi-calendar-check"></i>Pelunasan</a>
                        </div>
                        <div class="col-4">
                            <a href="aktif-gtc.html" class="btn btn-info mb-2"><i class="mdi mdi-arrow-left-bold-circle-outline"></i> Kembali</a>
                        </div>
                        <div class="col-4">
                            <a href="" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modal-view-pemohon"><i class="mdi mdi-card-search-outline"></i> Detail Pemohon</a>
                        </div><hr> 
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <p class="font-14"><strong>Nomor Buku Anggota :</strong> {{$row->nomor_ba}}</p>
                        </div>
                        <div class="col-sm-4">
                            <p class="font-14"><strong>Nama Lengkap :</strong> {{$row->nama_lengkap}}</p>
                        </div><hr>
                    </div>

                    <div class="" data-simplebar style="max-height: 500px;">
                        
                        <div class="row">
                            <div class="col-lg-6 card">
                                <div class="table-responsive">
                                    <br><h5>Data Pengajuan</h5>
                                </div>
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th style="width: 35%;"></th>
                                        <th style="width: 65%;"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Tanggal Pengajuan</td>
                                        <td>: {{$row->tanggal_pengajuan}}</td>
                                    </tr>
                                    <tr>
                                        <td>Perwada</td>
                                        <td>: {{$row->id_perwada}}</td>
                                    </tr>
                                    <tr>
                                        <td>Kode Pengajuan</td>
                                        <td>: {{$row->kode_pengajuan}}</td>
                                    </tr>
                                    <tr>
                                        <td>Pinjaman Awal</td>
                                        <td>: {{'Rp '. number_format($row->pengajuan,0,'.','.')}}</td>
                                    </tr>
                                    <tr>
                                        <td>Sisa Pinjaman</td>
                                        <td>: Rp 800.000</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div><br>
                            <div class="col-lg-6 card">
                                <div class="table-responsive">
                                    <br><h5>Update Transaksi Terahir</h5>
                                </div>
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th style="width: 35%;"></th>
                                        <th style="width: 65%;"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Jenis Transaksi</td>
                                        <td>: {{$row->jenis_transaksi}}</td>
                                    </tr>
                                    <tr>
                                        <td>Pilihan Jasa</td>
                                        <td>: {{$row->pilihan_jasa}}</td>
                                    </tr>
                                    <tr>
                                        <td>Perhitungan Jasa</td>
                                        <td>: {{$row->perhitungan_jasa}}</td>
                                    </tr>
                                    <tr>
                                        <td>Jangka Waktu</td>
                                        <td>: {{$row->jangka_waktu_permohonan . " Bulan"}}</td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Jasa</td>
                                        <td>: {{"Rp " . number_format($row->jasa_gtc,0,'.','.')}}</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div><br>
                            
                        </div>
                        <h5>Detail Emas GTC</h5>
                        <ul class="nav nav-tabs nav-bordered mb-3">
                            <li class="nav-item">
                                <a href="#pengajuan" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                    <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Pengajuan</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#pengambilan" data-bs-toggle="tab" aria-expanded="true" class="nav-link active">
                                    <i class="mdi mdi-account-circle d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Pengambilan Sebagian</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#sisaemasgtc" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                    <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Sisa Emas</span>
                                </a>
                            </li>
                        </ul>
                        
                        <div class="tab-content">
                            <div class="tab-pane" id="pengajuan">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                @php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                @endphp
                                                @foreach($emas as $row_emas)
                                                <tr>
                                                    <td>{{$row_emas ->item_emas}}</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">{{$row_emas->jenis}}</span>
                                                    </td>
                                                    <td>{{$row_emas->gramasi}}</td>
                                                    <td>{{$row_emas->keping}}</td>
                                                    <td>{{$row_emas->gramasi*$row_emas->keping . " Gram"}}</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                @endforeach
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        @php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        @endphp
                                                        {{$total_keping}}
                                                    </th>
                                                    <th>
                                                        @php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        @endphp
                                                        {{$total_gramasi. " Gram"}}
                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                            <div class="tab-pane show active" id="pengambilan">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                @php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                @endphp
                                                @foreach($emas as $row_emas)
                                                <tr>
                                                    <td>{{$row_emas ->item_emas}}</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">{{$row_emas->jenis}}</span>
                                                    </td>
                                                    <td>{{$row_emas->gramasi}}</td>
                                                    <td>{{$row_emas->keping}}</td>
                                                    <td>{{$row_emas->gramasi*$row_emas->keping . " Gram"}}</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                @endforeach
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        @php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        @endphp
                                                        {{$total_keping}}
                                                    </th>
                                                    <th>
                                                        @php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        @endphp
                                                        {{$total_gramasi. " Gram"}}
                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                            <div class="tab-pane" id="sisaemasgtc">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                @php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                @endphp
                                                @foreach($emas as $row_emas)
                                                <tr>
                                                    <td>{{$row_emas ->item_emas}}</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">{{$row_emas->jenis}}</span>
                                                    </td>
                                                    <td>{{$row_emas->gramasi}}</td>
                                                    <td>{{$row_emas->keping}}</td>
                                                    <td>{{$row_emas->gramasi*$row_emas->keping . " Gram"}}</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                @endforeach
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        @php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        @endphp
                                                        {{$total_keping}}
                                                    </th>
                                                    <th>
                                                        @php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        @endphp
                                                        {{$total_gramasi. " Gram"}}
                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="table-responsive">
                                    <h5>Tabel Transaksi</h5>
                                    <table id="list-data" class="table table-striped w-100 nowrap">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode Transaksi</th>
                                                <th>Jenis Transaksi</th>
                                                <th>Pilihan Jasa</th>
                                                <th>Perhitungan Jasa</th>
                                                <th>Jangka Waktu</th>
                                                <th>Biaya Jasa</th>
                                                <th>Pembayaran Jasa</th>
                                                <th>Nomor SBTE</th>
                                                <th>Status</th>
                                                <th>Action
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#modal-tambah-dataperpanjangan"><i class="mdi mdi-plus-box"></i></a>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no=1; ?>
                                            <!-- @foreach($data as $row)
                                            <tr>
                                                <td>{{$no++}}</td>
                                                <td>{{$row->kode_transaksi}}</td>
                                                <td>{{$row->jenis_transaksi}}</td>
                                                <td>{{$row->pilihan_jasa}}</td>
                                                <td>{{$row->perhitungan_jasa}}</td>
                                                <td>{{$row->jangka_waktu_permohonan." Bulan"}}</td>
                                                <td>{{"Rp ". number_format ($row->jasa_gtc,0,'.','.')}}</td>
                                                <td>{{"Rp ". number_format ($row->pembayaran_jasa_manual,0,'.','.')}}</td>
                                                <td>{{$row->sbte}}</td>
                                                <td>Pengajuan / Aproved </td>
                                                <td>
                                                    <a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="View Transaksi"> <i
                                                        class="mdi mdi-card-search"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#modal-upload-buktitrf" 
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Upload trf"> <i
                                                        class="mdi mdi-file-upload"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-opr"
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval OPR"> <i
                                                        class="mdi mdi-check-circle"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-keu"
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval Kasir"> <i
                                                        class="mdi mdi-check-circle"></i></a>
                                                    <a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Cetak SBTE"> <i
                                                        class="mdi mdi-printer-outline"></i></a>
                                                </td>
                                            </tr>
                                            @endforeach -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->

    </div> <!-- container -->


    <!-- Modal view-->
    @foreach($data as $row)
    <div class="modal fade" id="modal-view-pemohon" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #afb4be">
                    <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">View Data CIF Anggota</h4>
                    <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor Buku Anggota</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_nomor_buku_anggota"><strong>: {{$row->nomor_ba}}</strong> </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nama Lengkap</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nama_lengkap"><strong>: </strong>{{$row->nama_lengkap}}</h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor Hp</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nomor_hp"><strong>: </strong>{{$row->no_hp}}</h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>{{$row->no_hp}}</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_email"><strong>: </strong>{{$row->email}}</h>
                        </div><hr>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor KTP</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nomor_ktp"><strong>: </strong>{{$row->no_ktp}}</h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Jenis Kelamin</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_jenis_kelamin"><strong>: </strong>{{$row->jenis_kelamin}}</h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Tempat Lahir</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_tempat_lahir"><strong>: </strong>{{$row->tempat_lahir}}</h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Tanggal Lahir</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_tanggal_lahir"><strong>: </strong>{{$row->tanggal_lahir}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Status Pernikahan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_status_pernikahan"><strong>: </strong>{{$row->status_nikah}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor NPWP</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_nomor_npwp"><strong>: </strong>{{$row->no_npwp}}</p>
                        </div><hr>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Sesuai KTP</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_sesuai_ktp"><strong>: </strong>{{$row->alamat_ktp}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kecamatan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kecamatan"><strong>: </strong>@php $kecamatan_ktp = explode(",", $row->kecamatan_ktp); @endphp {{$kecamatan_ktp[1]}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kota_kabupaten"><strong>: </strong>@php $kota_ktp = explode(",", $row->kota_ktp); @endphp {{$kota_ktp[1]}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Provinsi</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_provinsi"><strong>: </strong>@php $provinsi_ktp = explode(",", $row->provinsi_ktp); @endphp {{$provinsi_ktp[1]}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Tinggal</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_tinggal"><strong>: </strong>@if($row->alamat_tinggal == 'sesuai') Sesuai KTP @elseif($row->alamat_tinggal == 'tidakSesuai') Tidak Sesuai KTP @endif</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Tinggal Saat ini</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_tinggal_domisili"><strong>: </strong>{{$row->alamat_domisili}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kecamatan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kecamatan_domisili"><strong>: </strong>@php $kecamatan_domisili = explode(",", $row->kecamatan_domisili); @endphp {{$kecamatan_domisili[1]}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kota_kabupaten_domisili"><strong>: </strong>@php $kota_domisili = explode(",", $row->kota_domisili); @endphp {{$kota_domisili[1]}}</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Provinsi</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_provinsi_domisili"><strong>: </strong>@php $provinsi_domisili = explode(",", $row->provinsi_domisili); @endphp {{$provinsi_domisili[1]}}</p>
                        </div><hr>
                    </div>
                    <div class="col-4">
                        <p class="font-14"><strong>Photo KTP</strong></p>
                    </div>
                    <img src="http://syirkah.eoaclubsystem.com/images/data_penting/ktp/{{$row->foto_ktp}}"  id="detail_photo_ktp" alt="image" class="img-fluid rounded" width="600"/>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    @endforeach
<div class="modal fade" id="modal-upload-buktitrf" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Upload Bukti Transfer (Pinjaman)</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row">
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Tanggal Transfer</label>
                            <input class="form-control" type="date" id="fullname"  required>
                        </div>
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Nominal Transfer (RP)</label>
                            <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="nominaltrf"  required>
                        </div>
                        <div class="mb-3">
                            <label for="example-fileinput" class="form-label">Upload Bukti Trf</label>
                            <input type="file" id="example-fileinput" class="form-control">
                        </div>
                        <div class="mb-3 text-center" >
                            <button class="btn btn-primary" type="submit"> Simpan </button>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div id="warning-aproval-opr" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4">
                <div class="text-center">
                    <i class="dripicons-warning h1 text-warning"></i>
                    <h4 class="mt-2">Perhatian</h4>
                    <p class="mt-3">Data Transaksi An. XXXXXXX Akan di <strong>Setujui</strong> Pastikan data yang akan di setujui lengkap & Sesuai</p>
                    <p> Silakan klik <strong>Aprov</strong> jika sudah yakin</p>
                    <button type="button" class="btn btn-success my-2" data-bs-dismiss="modal">Aprov</button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<div id="warning-aproval-keu" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4">
                <div class="text-center">
                    <i class="dripicons-warning h1 text-warning"></i>
                    <h4 class="mt-2">Perhatian</h4>
                    <p class="mt-3">Data Transaksi An. XXXXXXX Akan di <strong>Setujui</strong> Pastikan data yang akan di setujui lengkap & Sesuai</p>
                    <p> Silakan klik <strong>Aprov</strong> jika sudah yakin</p>
                    <button type="button" class="btn btn-success my-2" data-bs-dismiss="modal">Aprov</button>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

@endsection
@push('script')
<script>
    $(function () {
    var kode = $('#id_pengajuan').val()
    $('#list-data').DataTable({
        processing: true,
        serverSide: true,
        scrollX:!0,
        language:{
        paginate:{
            previous:"<i class='mdi mdi-chevron-left'>",
            next:"<i class='mdi mdi-chevron-right'>",
        }
        },
        // drawCallback:function(){
        //     $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
        // }
        order: [[0, "desc"]],
        ajax: '/backend/list-transaksi/' + kode,
        columns: [
            {
                data: 'id', render: function (data, type, row, meta) {
                    return meta.row + meta.settings._iDisplayStart + 1;
                }
            },
            { data: 'kode_transaksi', name: 'kode_transaksi' },
            { data: 'jenis_transaksi', name: 'jenis_transaksi' },
            { data: 'pilihan_jasa', name: 'pilihan_jasa' },
            { data: 'perhitungan_jasa', name: 'perhitungan_jasa' },
            { data: 'jangka_waktu_permohonan', name: 'jangka_waktu_permohonan' },
            { data: 'jasa_gtc', render: $.fn.dataTable.render.number( '.', ',', 0, 'Rp ' ), name: 'jasa_gtc' },
            { data: 'pembayaran_jasa_manual', render: $.fn.dataTable.render.number( '.', ',', 0, 'Rp ' ), name: 'pembayaran_jasa_manual' },
            { data: 'sbte', name: 'sbte' },
            { data: 'pilihan_jasa', name: 'pilihan_jasa' },
            {
                render: function (data, type, row) {
                    return '<a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="View Transaksi"> <i class="mdi mdi-card-search"></i></a> <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#modal-upload-buktitrf" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Upload trf"> <i class="mdi mdi-file-upload"></i></a><a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-opr" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval OPR"> <i class="mdi mdi-check-circle"></i></a><a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-keu" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval Kasir"> <i class="mdi mdi-check-circle"></i></a> <a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Cetak SBTE"> <i class="mdi mdi-printer-outline"></i></a>'
                },
                "className": 'text-center',
                "orderable": false,
                "data": null,
            },
        ],
        pageLength: 10,
        lengthMenu: [[5, 10, 20], [5, 10, 20]]
    });

});
// $("#scroll-horizontal-datatable").DataTable({
//     scrollX:!0,
//     language:{
//     paginate:{
//         previous:"<i class='mdi mdi-chevron-left'>",
//         next:"<i class='mdi mdi-chevron-right'>"
//     }
//     },
//     drawCallback:function(){
//         $(".dataTables_paginate > .pagination").addClass("pagination-rounded")
//     }
// })
</script>
@endpush