<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();
Route::prefix('backend')->group(function () {
    Route::get('/home', 'backend\HomeController@index')->name('home');
    Route::get('/edit-profile', 'backend\HomeController@editprofile')->name('editprofile');
    Route::post('/edit-profile/{id}', 'backend\HomeController@aksieditprofile');

    Route::resource('/roles','backend\rolesController');
    Route::get('/data-roles','backend\rolesController@listdata');
    
    Route::get('/data-admin','backend\AdminController@listdata');
    Route::resource('/admin','backend\AdminController');
    Route::get('/web-setting', 'backend\HomeController@websetting');
    Route::post('/web-setting', 'backend\HomeController@updatewebsetting');

    Route::resource('/harga-emas', 'backend\HargaemasController');
    Route::get('/cari-data-harga-harian', 'backend\HargaemasController@listdata');
    Route::get('/cari-data-harga-harian/{id}/edit', 'backend\HargaemasController@caridetailhargaharian');

    Route::resource('/jenis-jasa-gtc', 'backend\JenisjasagtcController');
    Route::get('/cari-data-jenis-jasa-gtc', 'backend\JenisjasagtcController@listdata');
    Route::get('/cari-data-jenis-jasa-gtc/{id}/edit', 'backend\JenisjasagtcController@caridetailjenisjasa');

    Route::resource('/pengajuan-gtc', 'backend\PengajuangtcController');
    Route::put('/tambah-data-cif-anggota/{id}', 'backend\PengajuangtcController@tambahdatacifanggota');
    Route::get('/cari-data-histori-anggota/{kode}', 'backend\PengajuangtcController@historianggota');
    Route::get('/aproval-bm-pengajuan-gtc/{id}', 'backend\PengajuangtcController@aprovalbmpengajuangtc');
    Route::put('/edit-aproval-bm-pengajuan-gtc/{id}', 'backend\PengajuangtcController@editaprovalbmpengajuangtc');
    Route::get('/aproval-opr-pengajuan-gtc/{id}', 'backend\PengajuangtcController@aprovaloprpengajuangtc');
    Route::put('/edit-aproval-opr-pengajuan-gtc/{id}', 'backend\PengajuangtcController@editaprovaloprpengajuangtc');
    Route::get('/aproval-keu-pengajuan-gtc/{id}', 'backend\PengajuangtcController@aprovalkeupengajuangtc');
    Route::put('/edit-aproval-keu-pengajuan-gtc/{id}', 'backend\PengajuangtcController@editaprovalkeupengajuangtc');
    Route::get('/tambah-pengajuan-gtc', 'backend\PengajuangtcController@tambahpengajuangtc');
    Route::get('/view-pengajuan-gtc/{id}', 'backend\PengajuangtcController@viewpengajuangtc');
    Route::get('/edit-pengajuan-gtc/{id}', 'backend\PengajuangtcController@editpengajuangtc');
    Route::get('/del-pengajuan-gtc', 'backend\PengajuangtcController@delpengajuangtc');
    Route::get('/view-histori-pengajuan/{id}', 'backend\PengajuangtcController@viewhistoripengajuan');
    Route::delete('/restore-histori-pengajuan/{id}', 'backend\PengajuangtcController@restorehistoripengajuan');
    Route::get('/cari-nomor-ba/{id}', 'backend\PengajuangtcController@carinomorba');
    Route::get('/cari-nomor-ba-hasil/{id}', 'backend\PengajuangtcController@carinomorbahasil');
    Route::get('/cari-kode-pengajuan-hasil/{id}', 'backend\PengajuangtcController@carikodepengajuanhasil');
    Route::get('/cari-data-emas-gtc/{kode}', 'backend\PengajuangtcController@listemasgtc');
    Route::post('/add-emas-gtc', 'backend\PengajuangtcController@addemasgtc');
    Route::delete('/delete-emas-gtc/{id}', 'backend\PengajuangtcController@deleteemasgtc');

    Route::get('/item-emas-syirkah/{id}', 'backend\PengajuangtcController@emassyirkah');
    Route::get('/tabel-emas-gtc', 'backend\PengajuangtcController@tabelemasgtc');
    Route::get('/add-tabel-emas-gtc/{id}/{pengajuan}', 'backend\PengajuangtcController@addtabelemasgtc');
    Route::put('/edit-keping/{id}', 'backend\PengajuangtcController@editkeping');

    Route::resource('/aktif-gtc', 'backend\AktifgtcController');
    Route::get('/transaksi-gtc/{id}', 'backend\AktifgtcController@transaksi');
    Route::get('/list-transaksi/{id}', 'backend\AktifgtcController@listtransaksi');
});
