<?php

namespace App\Http\Controllers\backend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use DB;
use DataTables;

class AktifgtcController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data = DB::table('gtc_pengajuan')
        ->leftjoin('anggota','anggota.id','=','gtc_pengajuan.id_anggota')
        ->select('gtc_pengajuan.*','gtc_pengajuan.id as idp','anggota.*','anggota.id as ida')
        ->where('status_akhir', 'Aktif')
        ->get();
        return view('backend.aktif_gtc.index', compact('data'));
    }

    public function transaksi($id)
    {
        $data = DB::table('gtc_pengajuan')
        ->leftjoin('anggota','anggota.id','=','gtc_pengajuan.id_anggota')
        ->leftjoin('gtc_transaksi', 'gtc_transaksi.kode_transaksi', 'gtc_pengajuan.kode_transaksi')
        ->select('gtc_pengajuan.*','gtc_pengajuan.id as idp','anggota.*','anggota.id as ida','gtc_transaksi.*','gtc_transaksi.id as idt')
        ->where('gtc_pengajuan.id', $id)
        ->get();

        $lastTransaksi = DB::table('gtc_transaksi')->where('sbte', '!=', '')->orderby('created_at', 'desc')->first();
        // dd($lastTransaksi);
        $sbte = $lastTransaksi->sbte;
        $kode = explode(".", $sbte);
        $kode2 = explode("-", $kode[2]);
        $kode3 = substr($kode2[0], -5);
        $kode3++;
        $kode4 = str_pad($kode3, 5, '0', STR_PAD_LEFT);
        // ==============
        $kodeperwada = "062";
        $kodedefault = "13";
        $carigender = DB::table("anggota")->where('id', '1')->first();
        $gender = $carigender->jenis_kelamin;
        if($gender == 'Laki-laki'){
            $kodegender = '12';
        }else if($gender == 'Perempuan'){
            $kodegender = '11';
        }
        $kodesistem = '0';
        $kodedefault2 = '04';
        $finalkode = $kodeperwada.'.'.$kodedefault.'.'.$kodegender.$kodesistem.$kode4.'-'.$kodedefault2;
        // dd($finalkode);
        
        return view('backend.aktif_gtc.transaksi', compact('data'));
    }

    public function listtransaksi($id)
    {
        return Datatables::of(DB::table('gtc_pengajuan')
        ->leftjoin('anggota','anggota.id','=','gtc_pengajuan.id_anggota')
        ->leftjoin('gtc_transaksi', 'gtc_transaksi.kode_transaksi', 'gtc_pengajuan.kode_transaksi')
        ->select('gtc_pengajuan.*','gtc_pengajuan.id as idp','anggota.*','anggota.id as ida','gtc_transaksi.*','gtc_transaksi.id as idt')
        ->where('gtc_pengajuan.id', $id)
        ->get())->make(true);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
