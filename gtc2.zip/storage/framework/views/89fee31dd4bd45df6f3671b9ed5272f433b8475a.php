<!-- Left navbar links -->
<ul class="navbar-nav">
    <li class="nav-item">
        <a href="<?php echo e(url('/backend/home')); ?>" class="nav-link">Home</a>
    </li>
    <?php if(auth()->user()->can('view-roles')
    || auth()->user()->can('create-roles')
    || auth()->user()->can('edit-roles')
    || auth()->user()->can('delete-roles')
    || auth()->user()->can('view-users')
    || auth()->user()->can('create-users')
    || auth()->user()->can('edit-users')
    || auth()->user()->can('delete-users')): ?>
    <li class="nav-item dropdown">
        <a id="dropdownSubMenu1" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"
            class="nav-link dropdown-toggle">Admin Management</a>
        <ul aria-labelledby="dropdownSubMenu1" class="dropdown-menu border-0 shadow">
            <?php if(auth()->user()->can('view-roles')
            || auth()->user()->can('create-roles')
            || auth()->user()->can('edit-roles')
            || auth()->user()->can('delete-roles')): ?>
            <li><a href="<?php echo e(url('backend/roles')); ?>" class="dropdown-item">Roles </a></li>
            <?php endif; ?>
            <?php if(auth()->user()->can('view-users')
            || auth()->user()->can('create-users')
            || auth()->user()->can('edit-users')
            || auth()->user()->can('delete-users')): ?>
            <li><a href="<?php echo e(url('backend/admin')); ?>" class="dropdown-item">Admin</a></li>
            <?php endif; ?>
        </ul>
    </li>
    <?php endif; ?>
    <?php if(auth()->user()->can('view-test')
    || auth()->user()->can('create-test')
    || auth()->user()->can('edit-test')
    || auth()->user()->can('delete-test')): ?>
    <li class="nav-item">
        <a href="<?php echo e(url('backend/test')); ?>" class="nav-link">test</a>
    </li>
    <?php endif; ?>
</ul><?php /**PATH D:\Kediri App\project\laravel\dboiler\dboilerlaravel-main\dboilerlaravel-main\resources\views/layouts/nav.blade.php ENDPATH**/ ?>