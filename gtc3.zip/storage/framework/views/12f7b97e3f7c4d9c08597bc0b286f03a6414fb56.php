
<?php $__env->startSection('css'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link rel="stylesheet" href="<?php echo e(asset('customjs/backend/loading.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Get The Cash</a></li>
                        <li class="breadcrumb-item active">View Transaksi GTC</li>
                    </ol>
                </div>
                <h4 class="page-title">Transaksi Data GTC</h4>
            </div>
        </div>
    </div>
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card d-block">
                <div class="card-header bg-secondary border-danger border-3" >
                    <div class=" align-items-center mb-2 text-white">
                        <h3>Transaksi GTC</h3>
                    </div>
                </div>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div id="panel" class="card-body">
                    <input type="hidden" name="id_pengajuan" id="id_pengajuan" value="<?php echo e($row->kode_pengajuan); ?>" class="form-control">
                    <input type="hidden" name="id_anggota" id="id_anggota" value="<?php echo e($row->ida); ?>" class="form-control">
                    <div class="row mb-2">
                        <div class="col-4">
                            <a class="btn btn-success mb-2"><i class="mdi mdi-calendar-check"></i>Pelunasan</a>
                        </div>
                        <div class="col-4">
                            <a href="aktif-gtc.html" class="btn btn-info mb-2"><i class="mdi mdi-arrow-left-bold-circle-outline"></i> Kembali</a>
                        </div>
                        <div class="col-4">
                            <a href="" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modal-view-pemohon"><i class="mdi mdi-card-search-outline"></i> Detail Pemohon</a>
                        </div><hr> 
                    </div>
                    <div class="row">
                        <div class="col-sm-4">
                            <p class="font-14"><strong>Nomor Buku Anggota :</strong> <?php echo e($row->nomor_ba); ?></p>
                        </div>
                        <div class="col-sm-4">
                            <p class="font-14"><strong>Nama Lengkap :</strong> <?php echo e($row->nama_lengkap); ?></p>
                        </div><hr>
                    </div>

                    <div class="" data-simplebar style="max-height: 500px;">
                        
                        <div class="row">
                            <div class="col-lg-6 card">
                                <div class="table-responsive">
                                    <br><h5>Data Pengajuan</h5>
                                </div>
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th style="width: 35%;"></th>
                                        <th style="width: 65%;"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Tanggal Pengajuan</td>
                                        <td>: <?php echo e($row->tanggal_pengajuan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Perwada</td>
                                        <td>: <?php echo e($row->id_perwada); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Kode Pengajuan</td>
                                        <td>: <?php echo e($row->kode_pengajuan); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pinjaman Awal</td>
                                        <td>: <?php echo e('Rp '. number_format($row->pengajuan,0,'.','.')); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Sisa Pinjaman</td>
                                        <td>: Rp 800.000</td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div><br>
                            <div class="col-lg-6 card">
                                <div class="table-responsive">
                                    <br><h5>Update Transaksi Terahir</h5>
                                </div>
                                <table class="table mb-0">
                                    <thead>
                                    <tr>
                                        <th style="width: 35%;"></th>
                                        <th style="width: 65%;"></th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <tr>
                                        <td>Jenis Transaksi</td>
                                        <td>: <?php echo e($row->jenis_transaksi); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Pilihan Jasa</td>
                                        <td>: <?php echo e($row->pilihan_jasa); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Perhitungan Jasa</td>
                                        <td>: <?php echo e($row->perhitungan_jasa); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Jangka Waktu</td>
                                        <td>: <?php echo e($row->jangka_waktu_permohonan . " Bulan"); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Biaya Jasa</td>
                                        <td>: <?php echo e("Rp " . number_format($row->jasa_gtc,0,'.','.')); ?></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div><br>
                            
                        </div>
                        <h5>Detail Emas GTC</h5>
                        <ul class="nav nav-tabs nav-bordered mb-3">
                            <li class="nav-item">
                                <a href="#pengajuan" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                    <i class="mdi mdi-home-variant d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Pengajuan</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#pengambilan" data-bs-toggle="tab" aria-expanded="true" class="nav-link active">
                                    <i class="mdi mdi-account-circle d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Pengambilan Sebagian</span>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="#sisaemasgtc" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                                    <i class="mdi mdi-settings-outline d-md-none d-block"></i>
                                    <span class="d-none d-md-block">Sisa Emas</span>
                                </a>
                            </li>
                        </ul>
                        
                        <div class="tab-content">
                            <div class="tab-pane" id="pengajuan">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                <?php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                ?>
                                                <?php $__currentLoopData = $emas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_emas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($row_emas ->item_emas); ?></td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten"><?php echo e($row_emas->jenis); ?></span>
                                                    </td>
                                                    <td><?php echo e($row_emas->gramasi); ?></td>
                                                    <td><?php echo e($row_emas->keping); ?></td>
                                                    <td><?php echo e($row_emas->gramasi*$row_emas->keping . " Gram"); ?></td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        <?php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        ?>
                                                        <?php echo e($total_keping); ?>

                                                    </th>
                                                    <th>
                                                        <?php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        ?>
                                                        <?php echo e($total_gramasi. " Gram"); ?>

                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                            <div class="tab-pane show active" id="pengambilan">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                <?php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                ?>
                                                <?php $__currentLoopData = $emas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_emas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($row_emas ->item_emas); ?></td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten"><?php echo e($row_emas->jenis); ?></span>
                                                    </td>
                                                    <td><?php echo e($row_emas->gramasi); ?></td>
                                                    <td><?php echo e($row_emas->keping); ?></td>
                                                    <td><?php echo e($row_emas->gramasi*$row_emas->keping . " Gram"); ?></td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        <?php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        ?>
                                                        <?php echo e($total_keping); ?>

                                                    </th>
                                                    <th>
                                                        <?php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        ?>
                                                        <?php echo e($total_gramasi. " Gram"); ?>

                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                            <div class="tab-pane" id="sisaemasgtc">
                                <div class="col-lg-12">
                                    <div class="table-responsive">
                                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                            <h5>Detail Emas Pengajuan GTC</h5>
                                            <thead class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Item emas</th>
                                                    <th>Jenis</th>
                                                    <th>Gramasi</th> 
                                                    <th>Keping</th>
                                                    <th>Jumlah Gramasi</th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                            </thead>
                                                <?php 
                                                    $emas = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->get();
                                                ?>
                                                <?php $__currentLoopData = $emas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_emas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($row_emas ->item_emas); ?></td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten"><?php echo e($row_emas->jenis); ?></span>
                                                    </td>
                                                    <td><?php echo e($row_emas->gramasi); ?></td>
                                                    <td><?php echo e($row_emas->keping); ?></td>
                                                    <td><?php echo e($row_emas->gramasi*$row_emas->keping . " Gram"); ?></td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <!-- <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>Gold 0.1 Gram</td>
                                                    <td>
                                                        <span class="badge badge-primary-lighten">Reguler</span>
                                                    </td>
                                                    <td>0.1</td>
                                                    <td>Rp 150.000</td>
                                                    <td>2</td>
                                                    <td>0.2 Gram</td>
                                                    <td>Rp 300.000</td>
                                                    <td>
                                                        <a href="javascript:void(0);" class="action-icon"> <i
                                                                class="mdi mdi-delete"></i></a>
                                                    </td>
                                                </tr> -->
                                            </tbody>
                                            <tfoot class="text-white bg-secondary ">
                                                <tr>
                                                    <th>Total</th>
                                                    <th></th>
                                                    <th></th>
                                                    <th>
                                                        <?php
                                                            $total_keping = DB::table('gtc_emas')->where('kode_pengajuan', $row->kode_pengajuan)->sum('keping');
                                                        ?>
                                                        <?php echo e($total_keping); ?>

                                                    </th>
                                                    <th>
                                                        <?php
                                                            $total_gramasi = DB::table('gtc_emas')
                                                            ->where('kode_pengajuan', $row->kode_pengajuan)
                                                            ->select(DB::raw('sum(gramasi*keping)as total_gramasi'))
                                                            ->get();
                                                            foreach($total_gramasi as $gramasi){
                                                                $total_gramasi = $gramasi->total_gramasi;
                                                            }
                                                        ?>
                                                        <?php echo e($total_gramasi. " Gram"); ?>

                                                    </th>
                                                    <th style="width: 50px;"></th>
                                                </tr>
                                                </tfoot>
                                            <tbody>
                                        </table>
                                    </div><hr><br>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <!-- <button id="reload">Klik</button> -->
                            <div class="card">
                                <div class="table-responsive">
                                    <h5>Tabel Transaksi</h5>
                                    <table id="list-data" class="table table-striped w-100 nowrap">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Kode Transaksi</th>
                                                <th>Jenis Transaksi</th>
                                                <th>Pilihan Jasa</th>
                                                <th>Perhitungan Jasa</th>
                                                <th>Jangka Waktu</th>
                                                <th>Biaya Jasa</th>
                                                <th>Pembayaran Jasa</th>
                                                <th>Nomor SBTE</th>
                                                <th>Status</th>
                                                <th>Action
                                                <a onclick="tambahtransaksi('<?php echo e($row->kode_pengajuan); ?>')" class="action-icon" title="Tambah Transaksi"><i class="mdi mdi-plus-box"></i></a>
                                                </th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $no=1; ?>
                                            <!-- <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($no++); ?></td>
                                                <td><?php echo e($row->kode_transaksi); ?></td>
                                                <td><?php echo e($row->jenis_transaksi); ?></td>
                                                <td><?php echo e($row->pilihan_jasa); ?></td>
                                                <td><?php echo e($row->perhitungan_jasa); ?></td>
                                                <td><?php echo e($row->jangka_waktu_permohonan." Bulan"); ?></td>
                                                <td><?php echo e("Rp ". number_format ($row->jasa_gtc,0,'.','.')); ?></td>
                                                <td><?php echo e("Rp ". number_format ($row->pembayaran_jasa_manual,0,'.','.')); ?></td>
                                                <td><?php echo e($row->sbte); ?></td>
                                                <td>Pengajuan / Aproved </td>
                                                <td>
                                                    <a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="View Transaksi"> <i
                                                        class="mdi mdi-card-search"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#modal-upload-buktitrf" 
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Upload trf"> <i
                                                        class="mdi mdi-file-upload"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-opr"
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval OPR"> <i
                                                        class="mdi mdi-check-circle"></i></a>
                                                    <a href="" class="action-icon" data-bs-toggle="modal" data-bs-target="#warning-aproval-keu"
                                                        data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Aproval Kasir"> <i
                                                        class="mdi mdi-check-circle"></i></a>
                                                    <a href="javascript:void(0);" class="action-icon" data-bs-container="#tooltip-container2" data-bs-toggle="tooltip" title="Cetak SBTE"> <i
                                                        class="mdi mdi-printer-outline"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->

    </div> <!-- container -->


    <!-- Modal view-->
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="modal-view-pemohon" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
            <div class="modal-content">
                <div class="modal-header" style="background-color: #afb4be">
                    <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">View Data CIF Anggota</h4>
                    <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor Buku Anggota</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_nomor_buku_anggota"><strong>: <?php echo e($row->nomor_ba); ?></strong> </p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nama Lengkap</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nama_lengkap"><strong>: </strong><?php echo e($row->nama_lengkap); ?></h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor Hp</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nomor_hp"><strong>: </strong><?php echo e($row->no_hp); ?></h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong><?php echo e($row->no_hp); ?></strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_email"><strong>: </strong><?php echo e($row->email); ?></h>
                        </div><hr>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor KTP</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_nomor_ktp"><strong>: </strong><?php echo e($row->no_ktp); ?></h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Jenis Kelamin</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_jenis_kelamin"><strong>: </strong><?php echo e($row->jenis_kelamin); ?></h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Tempat Lahir</strong></p>
                        </div>
                        <div class="col-8">
                            <h class="font-14" id="detail_tempat_lahir"><strong>: </strong><?php echo e($row->tempat_lahir); ?></h>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Tanggal Lahir</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_tanggal_lahir"><strong>: </strong><?php echo e($row->tanggal_lahir); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Status Pernikahan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_status_pernikahan"><strong>: </strong><?php echo e($row->status_nikah); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Nomor NPWP</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_nomor_npwp"><strong>: </strong><?php echo e($row->no_npwp); ?></p>
                        </div><hr>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Sesuai KTP</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_sesuai_ktp"><strong>: </strong><?php echo e($row->alamat_ktp); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kecamatan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kecamatan"><strong>: </strong><?php $kecamatan_ktp = explode(",", $row->kecamatan_ktp); ?> <?php echo e($kecamatan_ktp[1]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kota_kabupaten"><strong>: </strong><?php $kota_ktp = explode(",", $row->kota_ktp); ?> <?php echo e($kota_ktp[1]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Provinsi</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_provinsi"><strong>: </strong><?php $provinsi_ktp = explode(",", $row->provinsi_ktp); ?> <?php echo e($provinsi_ktp[1]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Tinggal</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_tinggal"><strong>: </strong><?php if($row->alamat_tinggal == 'sesuai'): ?> Sesuai KTP <?php elseif($row->alamat_tinggal == 'tidakSesuai'): ?> Tidak Sesuai KTP <?php endif; ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Alamat Tinggal Saat ini</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_alamat_tinggal_domisili"><strong>: </strong><?php echo e($row->alamat_domisili); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kecamatan</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kecamatan_domisili"><strong>: </strong><?php $kecamatan_domisili = explode(",", $row->kecamatan_domisili); ?> <?php echo e($kecamatan_domisili[1]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_kota_kabupaten_domisili"><strong>: </strong><?php $kota_domisili = explode(",", $row->kota_domisili); ?> <?php echo e($kota_domisili[1]); ?></p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-4">
                            <p class="font-14"><strong>Provinsi</strong></p>
                        </div>
                        <div class="col-8">
                            <p class="font-14" id="detail_provinsi_domisili"><strong>: </strong><?php $provinsi_domisili = explode(",", $row->provinsi_domisili); ?> <?php echo e($provinsi_domisili[1]); ?></p>
                        </div><hr>
                    </div>
                    <div class="col-4">
                        <p class="font-14"><strong>Photo KTP</strong></p>
                    </div>
                    <img src="http://syirkah.eoaclubsystem.com/images/data_penting/ktp/<?php echo e($row->foto_ktp); ?>"  id="detail_photo_ktp" alt="image" class="img-fluid rounded" width="600"/>
                </div>
            </div><!-- /.modal-content -->
        </div><!-- /.modal-dialog -->
    </div><!-- /.modal -->
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-tambah-transaksi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Tambah Transaksi</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form id="formtambahtransaksi" method="post" novalidate>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="tambah_id_pengajuan" name="tambah_id_pengajuan" class="form-control">
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Perwada (sesuai dg Akun)</label>
                            <input class="form-control" type="text" id="tambah_id_perwada" name="tambah_id_perwada" placeholder="KP Jakarta" readonly="">
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kode Pengajuan</label>
                            <input class="form-control" type="text" id="tambah_kode_pengajuan" name="tambah_kode_pengajuan" placeholder="CSesuai Dengan Kode Pengajuan" readonly="">
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kode Transaksi</label>
                                <input class="form-control" type="text" id="tambah_kode_transaksi" name="tambah_kode_transaksi" placeholder="Sesuai Rumus" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Jenis Transaksi</label>
                                <select class="form-select" id="tambah_jenis_transaksi" name="tambah_jenis_transaksi" required>
                                    <option selected>Pilih</option>
                                    <option value="Perpanjangan">Perpanjangan</option>
                                    <option value="Pelunasan Sebagian">Pelunasan Sebagian</option>
                                    <option value="Pelunasan">Pelunasan</option>
                                </select>
                            </div>
                        </div><br><br><hr>
                        <div id="divemassebelumnya" style="display: none;">
                            <h5>EMAS Sebelumnya (Jika Pilihan Pelunasan / Pelunasan Sebagian)</h5>
                            <div class="table-responsive">
                                <table class="table table-borderless table-nowrap table-centered mb-0">
                                    <thead class="text-white bg-secondary ">
                                        <tr>
                                            <th>Item emas</th>
                                            <th>Jenis</th>
                                            <th>Gramasi</th> 
                                            <th>Keping</th>
                                            <th>Gramasi Sebelumnya</th>
                                            <th>Pengurangan</th>
                                            <th>Gramasi Pengurangan</th>
                                        </tr>
                                    </thead>
                                    <tfoot id="footemassebelumnya" class="text-white bg-secondary ">
                                        <tr>
                                            <th>Total</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th id="total_keping">0</th>
                                            <th id="total_gramasi">0</th>
                                            <th id="total_buyback">0</th>
                                            <th style="width: 50px;"></th>
                                        </tr>
                                        </tfoot>
                                    <tbody id="bodyemassebelumnya">
                                        <!-- <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>
                                                <input type="number" min="1" value="2" class="form-control"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>
                                                <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                    placeholder="Qty" style="width: 90px;" >
                                            </td>
                                            <td>0.2 Gram</td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>
                                                <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>
                                                <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                    placeholder="Qty" style="width: 90px;" >
                                            </td>
                                            <td>0.2 Gram</td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>
                                                <input type="number" min="1" value="2" class="form-control"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>
                                                <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td>0.2 Gram</td>
                                        </tr> -->
                                    </tbody>
                                </table>
                            </div><hr>
                        </div>
                        <div id="divemasselanjutnya" style="display: none;">
                            <h5>EMAS Selanjutnya </h5>
                            <div class="table-responsive">
                                <table class="table table-borderless table-nowrap table-centered mb-0">
                                    <thead class="text-white bg-secondary ">
                                        <tr>
                                            <th>Item emas</th>
                                            <th>Jenis</th>
                                            <th>Gramasi</th>
                                            <th>Harga Buyback</th> 
                                            <th>Keping</th>
                                            <th>Jumlah Gramasi</th>
                                            <th>Jumlah Buyback</th>
                                        </tr>
                                    </thead>
                                    <tfoot id="footemasselanjutnya" class="text-white bg-secondary ">
                                        <tr>
                                            <th>Total</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th id="total_keping2">0</th>
                                            <th id="total_gramasi2">0</th>
                                            <th id="total_buyback2">0</th>
                                            <th style="width: 50px;"></th>
                                        </tr>
                                    </tfoot>
                                    <tbody id="bodyemasselanjutnya">
                                        <!-- <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>Rp 150.000</td>
                                            <td>
                                                <input type="number" min="1" value="2" class="form-control"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>Rp 300.000</td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>Rp 150.000</td>
                                            <td>
                                                <input type="number" min="1" value="2" class="form-control"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>Rp 300.000</td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td>0.1</td>
                                            <td>Rp 150.000</td>
                                            <td>
                                                <input type="number" min="1" value="2" class="form-control"
                                                    placeholder="Qty" style="width: 90px;" readonly>
                                            </td>
                                            <td>0.2 Gram</td>
                                            <td>Rp 300.000</td>
                                        </tr> -->
                                    </tbody>
                                </table>
                                <input type="hidden" class="form-control" id="total_buyback2_hidden" name="total_buyback2_hidden">
                            </div><hr>
                        </div>
                        <div id="divpelunasan" style="display: none;">
                            <div class="row g-2">
                                <h5>jika pelunasan & pelunasan sebagian</h5>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Nominal Pinjaman (RP)</label>
                                    <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="tambah_nominal_pinjaman" name="tambah_nominal_pinjaman"  readonly>
                                    <input type="hidden" class="form-control" id="hidden_tambah_nominal_pinjaman" name="hidden_tambah_nominal_pinjaman">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pembayaran Pinjaman (RP)</label>
                                    <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="tambah_pembayaran_pinjaman" name="tambah_pembayaran_pinjaman" placeholder="0" required>
                                    <input type="hidden" class="form-control" id="hidden_tambah_pembayaran_pinjaman" name="hidden_tambah_pembayaran_pinjaman">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Sisa Pinjaman (RP)</label>
                                    <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="tambah_sisa_pinjaman" name="tambah_sisa_pinjaman"  readonly>
                                    <input type="hidden" class="form-control" id="hidden_tambah_sisa_pinjaman" name="hidden_tambah_sisa_pinjaman">
                                </div>
                            </div><br><hr>
                        </div>
                        <div id="divtransaksi"  style="display: none;">
                            <div class="row g-2">
                                <input type="hidden" id="tambah_plafond_pinjaman" name="tambah_plafond_pinjaman" class="form-control">
                                <input type="hidden" id="tambah_plafond_pinjaman_hidden" name="tambah_plafond_pinjaman_hidden" class="form-control">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pilihan Jasa</label>
                                    <input class="form-control" type="text" id="tambah_pilihan_jasa" name="tambah_pilihan_jasa" placeholder="Jasa diawal" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Perhitungan Jasa</label>
                                    <input class="form-control" type="text" id="tambah_perhitungan_jasa" name="tambah_perhitungan_jasa" placeholder="Perhitungan Baru" readonly="">
                                    <input type="hidden" class="form-control" id="tambah_jangka_waktu_1">
                                    <input type="hidden" class="form-control" id="tambah_pengali_kurangdari_satudelapan_1">
                                    <input type="hidden" class="form-control" id="tambah_pengali_diatas_dua_1">
                                    <input type="hidden" class="form-control" id="tambah_jangka_waktu_2">
                                    <input type="hidden" class="form-control" id="tambah_pengali_kurangdari_satudelapan_2">
                                    <input type="hidden" class="form-control" id="tambah_pengali_diatas_dua_2">
                                    <input type="hidden" class="form-control" id="tambah_jangka_waktu_3">
                                    <input type="hidden" class="form-control" id="tambah_pengali_kurangdari_satudelapan_3">
                                    <input type="hidden" class="form-control" id="tambah_pengali_diatas_dua_3">
                                    <input type="hidden" class="form-control" id="tambah_jangka_waktu_4">
                                    <input type="hidden" class="form-control" id="tambah_pengali_kurangdari_satudelapan_4">
                                    <input type="hidden" class="form-control" id="tambah_pengali_diatas_dua_4">
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Jangka Waktu Permohonan</label>
                                    <select class="form-select" id="tambah_jangka_waktu_permohonan" name="tambah_jangka_waktu_permohonan" required>
                                        <option selected>Pilih</option>
                                        <option value="0.5">15 Hari</option>
                                        <option value="1">1 Bulan</option>
                                        <option value="2">2 Bulan</option>
                                    </select>
                                </div>
                                
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jasa GTC(otomatis)</label>
                                    <input class="form-control" type="text" id="tambah_jasa_gtc" name="tambah_jasa_gtc" placeholder="0" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Pembayaran Jasa</label>
                                    <select class="form-select" id="tambah_pembayaran_jasa" name="tambah_pembayaran_jasa" required>
                                        <option>Transfer</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Bukti Transfer</label>
                                    <input class="form-control" type="file" id="tambah_upload_bukti_transfer" name="tambah_upload_bukti_transfer">
                                </div><hr>
                            </div><br>
                        </div>
                        <div id="divpembayaran" style="display: none;">
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pembayaran</label>
                                    <input class="form-control" type="text" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" id="tambah_pembayaran" name="tambah_pembayaran" placeholder="0">
                                    <input type="hidden" class="form-control" id="tambah_pembayaran_hidden" name="tambah_pembayaran_hidden">
                                </div>
                            </div><br>
                        </div>
                        <div id="divbtnsimpan" style="display: none;">
                            <div class="mb-3 text-center" >
                                <button class="btn btn-primary" id="btntambahtransaksi" name="btntambahtransaksi" type="submit"> Simpan </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="modal-view-transaksi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Lihat Transaksi</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-2">
                    <div class="col-4">
                        <a class="btn btn-success mb-2"><i class="mdi mdi-printer"></i>Cetak Transaksi</a>
                    </div><hr> 
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor Buku Anggota</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14"><strong>: 0.123.1234567</strong> </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nama Lengkap</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14"><strong>: </strong>Mukhammad Nasorudin Maulana</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kode Pengajuan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14"><strong>: </strong>A.1234567.1</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kode Transaksi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14"><strong>: </strong>B.1234567.1.1</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Jenis Transaksi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14"><strong>: </strong>Pengajuan Baru</p>
                    </div>
                </div><hr>
                <h5>EMAS Sebelumnya (Ini Muncul Jika data ada)</h5>
                <div class="table-responsive">
                    <table class="table table-borderless table-nowrap table-centered mb-0">
                                <thead class="text-white bg-secondary ">
                                    <tr>
                                        <th>Item emas</th>
                                        <th>Jenis</th>
                                        <th>Gramasi</th> 
                                        <th>Keping</th>
                                        <th>Gramasi Sebelumnya</th>
                                        <th>Pengurangan</th>
                                        <th>Gramasi Pengurangan</th>
                                    </tr>
                                </thead>
                                <tfoot class="text-white bg-secondary ">
                                    <tr>
                                        <th>Total</th>
                                        <th></th>
                                        <th></th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                    </tr>
                                    </tfoot>
                                <tbody>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                </tbody>
                    </table>
                </div><hr>
                <h5>EMAS Selanjutnya </h5>
                <div class="table-responsive">
                        <table class="table table-borderless table-nowrap table-centered mb-0">
                                <thead class="text-white bg-secondary ">
                                    <tr>
                                        <th>Item emas</th>
                                        <th>Jenis</th>
                                        <th>Gramasi</th>
                                        <th>Harga Buyback</th> 
                                        <th>Keping</th>
                                        <th>Jumlah Gramasi</th>
                                        <th>Jumlah Buyback</th>
                                    </tr>
                                </thead>
                                <tfoot class="text-white bg-secondary ">
                                    <tr>
                                        <th>Total</th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                        <th>Rp 900.0000</th>
                                    </tr>
                                    </tfoot>
                                <tbody>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                </tbody>
                        </table>
                </div><hr>
                <table class="table mb-0">
                    <thead>
                    <tr>
                        <th style="width: 35%;"></th>
                        <th style="width: 65%;"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Nominal Pinjaman</td>
                        <td>: Rp 10.000.000</td>
                    </tr>
                    <tr>
                        <td>Pembayaran Pinjaman</td>
                        <td>: Rp 5.000.000</td>
                    </tr>
                    <tr>
                        <td>Pinjaman Saat ini/Sisa Pinjaman</td>
                        <td>: Rp 5.000.000</td>
                    </tr>
                    <tr>
                        <td>Pilihan Jasa</td>
                        <td>: Jasa Di awal</td>
                    </tr>
                    <tr>
                        <td>Perhitungan Jasa</td>
                        <td>: Jasa Baru</td>
                    </tr>
                    <tr>
                        <td>Jangka Waktu Permohonan</td>
                        <td>: 1 Bulan</td>
                    </tr>
                    <tr>
                        <td>Jasa GTC</td>
                        <td>: Rp. 20.000</td>
                    </tr>
                    <tr>
                        <td>Pembayaran Jasa</td>
                        <td>: Transfer</td>
                    </tr>
                    <tr>
                        <td>Pembayaran</td>
                        <td>: Rp. 20.000</td>
                    </tr>
                    </tbody>
                </table><br>
                <div class="col-4">
                    <p class="font-14"><strong>Bukti Transfer (Pembayaran)</strong></p>
                </div>
                <img src="assets/images/small/small-2.jpg" alt="image" class="img-fluid rounded" width="600"/>
                <hr>
                <div class="col-4">
                    <p class="font-14"><strong>Bukti Transfer (Pinjaman)</strong></p>
                </div>
                <img src="assets/images/small/small-2.jpg" alt="image" class="img-fluid rounded" width="600"/>
                <hr>
                <div class="table-responsive">
                    <br><h5>Status Aproval</h5>
                </div>
                <table class="table mb-0">
                    <thead>
                    <tr>
                        <th style="width: 35%;"></th>
                        <th style="width: 65%;"></th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr>
                        <td>Status Aproval</td>
                        <td>: Pengajuan / Aprove</td>
                    </tr>
                    <tr>
                        <td>Aproval OPR</td>
                        <td>: 20 Mei 2022 13:30 (Akun Aproval)</td>
                    </tr>
                    <tr>
                        <td>Aproval Keu</td>
                        <td>: 20 Mei 2022 13:30 (Akun Aproval)</td>
                    </tr>
                    </tbody>
                </table>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-upload-buktitrf" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Upload Bukti Transfer (Pinjaman)</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form id="formbuktitrf">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="put">
                    <input type="hidden" name="buktitrf_id_transaksi" id="buktitrf_id_transaksi" class="form-control">
                    <div class="row">
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Tanggal Transfer</label>
                            <input class="form-control datepicker" type="text" name="buktitrf_tgl" id="buktitrf_tgl" value="<?php echo e(date('d/m/Y')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="fullname" class="form-label">Nominal Transfer (RP)</label>
                            <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" name="buktitrf_nominal" id="buktitrf_nominal" required>
                        </div>
                        <div class="mb-3">
                            <label for="example-fileinput" class="form-label">Upload Bukti Trf</label>
                            <input type="file" name="buktitrf_upload" id="buktitrf_upload" class="form-control">
                            <input type="hidden" name="old_buktitrf_upload" id="old_buktitrf_upload" class="form-control">
                        </div>
                        <div class="mb-3 text-center" >
                            <button class="btn btn-primary" type="submit" id="btnbuktitrf"> Simpan </button>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-edit-transaksi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Edit Transaksi</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Perwada (sesuai dg Akun)</label>
                            <input class="form-control" type="text" id="fullname" placeholder="KP Jakarta" readonly="">
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kode Pengajuan</label>
                            <input class="form-control" type="text" id="fullname" placeholder="CSesuai Dengan Kode Pengajuan" readonly="">
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kode Transaksi</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Sesuai Rumus" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Jenis Transaksi</label>
                                <select class="form-select" id="example-select" required>
                                    <option selected>Pilih</option>
                                    <option>Perpanjangan</option>
                                    <option>Pelunasan Sebagian</option>
                                    <option>Pelunasan</option>
                                </select>
                            </div>
                        </div><br><br><hr>
                        <h5>EMAS Sebelumnya (Jika Pilihan Pelunasan / Pelunasan Sebagian)</h5>
                        <div class="table-responsive">
                            <table class="table table-borderless table-nowrap table-centered mb-0">
                                <thead class="text-white bg-secondary ">
                                    <tr>
                                        <th>Item emas</th>
                                        <th>Jenis</th>
                                        <th>Gramasi</th> 
                                        <th>Keping</th>
                                        <th>Gramasi Sebelumnya</th>
                                        <th>Pengurangan</th>
                                        <th>Gramasi Pengurangan</th>
                                    </tr>
                                </thead>
                                <tfoot class="text-white bg-secondary ">
                                    <tr>
                                        <th>Total</th>
                                        <th></th>
                                        <th></th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                    </tr>
                                    </tfoot>
                                <tbody>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" >
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;" >
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>
                                            <input type="text" min="1" value="2" class="form-control" data-toggle="input-mask" data-mask-format="000"
                                                placeholder="Qty" style="width: 90px;">
                                        </td>
                                        <td>0.2 Gram</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div><hr>
                        <h5>EMAS Selanjutnya </h5>
                        <div class="table-responsive">
                            <table class="table table-borderless table-nowrap table-centered mb-0">
                                <thead class="text-white bg-secondary ">
                                    <tr>
                                        <th>Item emas</th>
                                        <th>Jenis</th>
                                        <th>Gramasi</th>
                                        <th>Harga Buyback</th> 
                                        <th>Keping</th>
                                        <th>Jumlah Gramasi</th>
                                        <th>Jumlah Buyback</th>
                                    </tr>
                                </thead>
                                <tfoot class="text-white bg-secondary ">
                                    <tr>
                                        <th>Total</th>
                                        <th></th>
                                        <th></th>
                                        <th></th>
                                        <th>6 Keping</th>
                                        <th>0.6 Gram</th>
                                        <th>Rp 900.0000</th>
                                    </tr>
                                    </tfoot>
                                <tbody>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                    <tr>
                                        <td>Gold 0.1 Gram</td>
                                        <td>
                                            <span class="badge badge-primary-lighten">Reguler</span>
                                        </td>
                                        <td>0.1</td>
                                        <td>Rp 150.000</td>
                                        <td>
                                            <input type="number" min="1" value="2" class="form-control"
                                                placeholder="Qty" style="width: 90px;" readonly>
                                        </td>
                                        <td>0.2 Gram</td>
                                        <td>Rp 300.000</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div><hr>
                        <div class="row g-2">
                            <h5>jika pelunasan & pelunasan sebagian</h5>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Nominal Pinjaman (RP)</label>
                                <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="nominaltrf"  readonly>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Pembayaran Pinjaman (RP)</label>
                                <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="nominaltrf"  required>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Sisa Pinjaman (RP)</label>
                                <input class="form-control" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" type="text" id="nominaltrf"  readonly>
                            </div>
                        </div><br><hr>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Pilihan Jasa</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Jasa diawal" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Perhitungan Jasa</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Perhitungan Baru" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Jangka Waktu Permohonan</label>
                                <select class="form-select" id="example-select" required>
                                    <option selected>Pilih</option>
                                    <option>15 Hari</option>
                                    <option>1 Bulan</option>
                                    <option>2 Bulan</option>
                                </select>
                            </div>
                            
                        </div><br>
                        
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Jasa GTC(otomatis)</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Rp 20.000" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Pembayaran Jasa</label>
                                <select class="form-select" id="example-select" required>
                                    <option>Transfer</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="formFile" class="form-label">Upload Buti Transfer</label>
                                <input class="form-control" type="file" id="formFile">
                            </div><hr>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Pembayaran</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Rp 20.000">
                            </div>
                        </div><br>
                        <div class="mb-3 text-center" >
                            <button class="btn btn-primary" type="submit"> Simpan </button>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-jasadiahir-transaksi" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Transaksi Jasa Di Akhir</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <form>
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Perwada (sesuai dg Akun)</label>
                            <input class="form-control" type="text" id="fullname" placeholder="KP Jakarta" readonly="">
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kode Pengajuan</label>
                            <input class="form-control" type="text" id="fullname" placeholder="CSesuai Dengan Kode Pengajuan" readonly="">
                        </div>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kode Transaksi</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Sesuai Rumus" readonly="">
                            </div>
                        </div><br><br><hr>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Pilihan Jasa</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Jasa diawal" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Perhitungan Jasa</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Perhitungan Baru" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Jangka Waktu Permohonan</label>
                                <select class="form-select" id="example-select" required>
                                    <option selected>Pilih</option>
                                    <option>15 Hari</option>
                                    <option>1 Bulan</option>
                                    <option>2 Bulan</option>
                                </select>
                            </div>
                            
                        </div><br>
                        
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Jasa GTC(otomatis)</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Rp 20.000" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Pembayaran Jasa</label>
                                <select class="form-select" id="example-select" required>
                                    <option>Transfer</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="formFile" class="form-label">Upload Buti Transfer</label>
                                <input class="form-control" type="file" id="formFile">
                            </div><hr>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Pembayaran</label>
                                <input class="form-control" type="text" id="fullname" placeholder="Rp 20.000">
                            </div>
                        </div><br>
                        <div class="mb-3 text-center" >
                            <button class="btn btn-primary" type="submit"> Simpan </button>
                        </div>
                    </div>
                </form>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div id="warning-aproval-opr" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4">
                <div class="text-center">
                    <i class="dripicons-warning h1 text-warning"></i>
                    <h4 class="mt-2">Perhatian</h4>
                    <p class="mt-3">Data Transaksi An. XXXXXXX Akan di <strong>Setujui</strong> Pastikan data yang akan di setujui lengkap & Sesuai</p>
                    <p> Silakan klik <strong>Aprov</strong> jika sudah yakin</p>
                    <form id="formaprovalopr">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="put">
                        <input type="hidden" name="aprovalopr_id_transaksi" id="aprovalopr_id_transaksi" class="form-control">
                        <button id="btnaprovalopr" type="submit" class="btn btn-success my-2">Aprov</button>
                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<div id="warning-aproval-keu" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-body p-4">
                <div class="text-center">
                    <i class="dripicons-warning h1 text-warning"></i>
                    <h4 class="mt-2">Perhatian</h4>
                    <p class="mt-3">Data Transaksi An. XXXXXXX Akan di <strong>Setujui</strong> Pastikan data yang akan di setujui lengkap & Sesuai</p>
                    <p> Silakan klik <strong>Aprov</strong> jika sudah yakin</p>
                    <form id="formaprovalkeu">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="put">
                        <input type="hidden" class="form-control" name="aprovalkeu_id_transaksi" id="aprovalkeu_id_transaksi">
                        <button id="btnaprovalkeu" type="submit" class="btn btn-success my-2">Aprov</button>
                    </form>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('customjs/backend/transaksi.js')); ?>"></script>
<script src="<?php echo e(asset('customjs/backend/loading.js')); ?>"></script>
<script>
    $('.datepicker').datepicker({
        format: 'dd/mm/yyyy',
    });
</script>
<!-- <script>
    reload();
    function reload(){
        $('#reload').on('click', function(e){
            $('#list-data').DataTable().ajax.reload();
        })
    }
</script> -->
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\gtc\resources\views/backend/aktif_gtc/transaksi.blade.php ENDPATH**/ ?>