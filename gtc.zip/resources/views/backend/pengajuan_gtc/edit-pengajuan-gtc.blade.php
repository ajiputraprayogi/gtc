@extends('layouts.base')
@section('css')
<meta name="csrf-token" content="{{ csrf_token() }}">
<link href="{{asset('assets/plugins/select2/css/select2.min.css')}}" rel="stylesheet" />
<link rel="stylesheet" href="{{asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')}}">
<link rel="stylesheet" href="{{asset('customjs/backend/loading.css')}}">
@endsection
@section('content')
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Get The Cash</a></li>
                        <li class="breadcrumb-item active">Pengajuan GTC</li>
                    </ol>
                </div>
                <h4 class="page-title">Pengajuan GTC</h4>
            </div>
        </div>
    </div>
    <!-- end page title --> 


    <div class="row" id="panel">
        <div class="col-12">
            <div class="card d-block">
                <div class="card-header bg-secondary border-danger border-3" >
                    <div class=" align-items-center mb-2 text-white">
                        <h3>Form Pengajuan GTC</h3>
                    </div>
                </div>
                <div class="card-body">
                    <div class="py-0">
                        <h5>Data Pemohon</h5>
                    </div><hr>
                    @foreach($data as $row)
                    @php
                        $dataanggota = DB::table('anggota')->get();
                    @endphp
                    <form action="{{url('/backend/pengajuan-gtc')}}" id="formaddpengajuangtc" method="post">
                    @csrf
                        <input type="hidden" name="_method" value="put">
                        <input type="hidden" name="id_pengajuan" id="id_pengajuan" value="{{$row->idp}}" class="form-control">
                        <div class="row g-2">
                            <div class="col-md">
                                <label class="form-label">Nomor BA</label>
                                <div class="input-group">
                                    <select type="text" class="form-control" id="nomor_ba" aria-label="Recipient's username">
                                        @foreach($dataanggota as $anggota)
                                            <option @if($anggota->id == $row->id_anggota) selected @endif>{{$row->nomor_ba}}</option>
                                        @endforeach
                                    </select>
                                    <input type="hidden" class="form-control" value="{{$row->id_anggota}}" id="id_anggota" name="id_anggota">
                                </div>
                                <!-- <div class="input-group">
                                    <input type="text" class="form-control" placeholder="x.xxx.xxxxx23" aria-label="Recipient's username" readonly>
                                    <button class="btn btn-primary" type="button">Cari</button>
                                </div> -->
                                </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Nama Lengkap</label>
                                <input class="form-control" type="text" id="nama_lengkap" value="{{$row->nama_lengkap}}" placeholder="Nama Sesuai" readonly="">
                            </div>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Nomor HP</label>
                                <input class="form-control" type="text" id="no_hp" value="{{$row->no_hp}}" placeholder="xxxxxxxxxx985" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="emailaddress" class="form-label">Email address</label>
                                <input class="form-control" type="email" id="email" value="{{$row->email}}" placeholder="xxxxx788@gmail.com" readonly=""> 
                            </div>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-6">
                            </div>
                            <div class="col-sm-6">
                                <a href="" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modal-view-pemohon" id="detailpemohonbtn" style="display: show"><i class="mdi mdi-card-search-outline"></i> Detail Pemohon</a>
                                <a href="" class="btn btn-danger mb-2" data-bs-toggle="modal" data-bs-target="#modal-tambah-datacif" id="datacifanggotabtn"  style="display: show"><i class="mdi mdi-plus-circle me-2"></i> Data CIF Anggota</a>
                            </div><br>
                        </div>
                        <div class="py-0">
                            <h5>Data Pengajuan</h5>
                        </div><hr>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Perwada (sesuai dg Akun)</label>
                                <input class="form-control" type="text" id="perwada" value="KP Jakarta" placeholder="KP Jakarta" readonly="">
                                <input type="hidden" value="{{$row->id_perwada}}" id="id_perwada" name="id_perwada" class="form-control">
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kode Pengajuan</label>
                                <input class="form-control" type="text" id="kode_pengajuan" value="{{$row->kode_pengajuan}}" name="kode_pengajuan" placeholder="Create by System" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Tujuan</label>
                                <select class="form-select" id="tujuan" name="tujuan" required>
                                    <option selected>Pilih</option>
                                    <option value="Untuk Modal Usaha" @if($row->tujuan == 'Untuk Modal Usaha') selected @endif>Untuk Modal Usaha</option>
                                    <option value="Biaya Pendidikan" @if($row->tujuan == 'Biaya Pendidikan') selected @endif>Biaya Pendidikan</option>
                                    <option value="Investasi" @if($row->tujuan == 'Investasi') selected @endif>Investasi</option>
                                    <option value="Pembelian Barang" @if($row->tujuan == 'Pembelian Barang') selected @endif>Pembelian Barang</option>
                                    <option value="Lainnya" @if($row->tujuan == 'Lainnya') selected @endif>Lainnya</option>
                                </select>
                            </div>
                        </div><hr><br>

                        <div class="col-lg-12">
                            <div class="col-sm-5">
                                <a id="btnmodaladdemasgtc" href="javascript:void(0);" class="btn mb-2 text-white bg-primary" data-bs-toggle="modal" data-bs-target="#addemasgtc" style="display: show"><i class="mdi mdi-plus-circle me-2"></i> Emas GTC</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-borderless table-nowrap table-centered mb-0">
                                    <thead class="text-white bg-secondary ">
                                        <tr>
                                            <th>Item emas</th>
                                            <th>Jenis</th>
                                            <th>Gramasi</th>
                                            <th>Harga Buyback</th> 
                                            <th>Keping</th>
                                            <th>Jumlah Gramasi</th>
                                            <th>Jumlah Buyback</th>
                                            <th style="width: 50px;"></th>
                                        </tr>
                                    </thead>
                                    <tfoot id="footemasgtc" class="text-white bg-secondary ">
                                        <!-- <tr>
                                            <th>Total</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th id="total_keping">0</th>
                                            <th id="total_gramasi">0</th>
                                            <th id="total_buyback">0</th>
                                            <th style="width: 50px;"></th>
                                        </tr> -->
                                    </tfoot>
                                    <tbody id="bodyemasgtc">
                                        <!-- <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td class="gramasi">0.1</td>
                                            <td class="harga_buyback">150000</td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a href="javascript:void(0);" class="action-icon"> <i
                                                        class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td class="gramasi">0.2</td>
                                            <td class="harga_buyback">300000</td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a href="javascript:void(0);" class="action-icon"> <i
                                                        class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr> -->
                                        <!-- @foreach($emas_gtc as $item)
                                        <tr>
                                            <td>{{$item->item_emas}}</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">{{$item->jenis}}</span>
                                            </td>
                                            <td class="gramasi">{{$item->gramasi}}</td>
                                            <td class="harga_buyback">{{$item->harga_buyback}}</td>
                                            <td hidden class="harga_buyback_hidden">{{$item->harga_buyback}}</td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a onclick="hapusdataemasgtc({{$item->id}})" class="action-icon"> <i class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr>
                                        @endforeach -->
                                    </tbody>
                                </table>
                            </div><hr><br> <!-- end table-responsive-->

                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Plafond Pinjaman</label>
                                    <input class="form-control" type="text" id="plafond_pinjaman" value="{{$row->plafond_pinjaman}}" name="plafond_pinjaman" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required readonly>
                                    <!-- <input type="text" class="form-control" id="plafond_pinjaman_hidden"> -->
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pengajuan</label>
                                    <input class="form-control" type="text" id="pengajuan" name="pengajuan" value="{{$row->pengajuan}}" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                    <!-- <input type="text" class="form-control" id="pengajuan_hidden"> -->
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Pilihan Bank</label>
                                    <select class="form-select" id="pilihan_bank" name="pilihan_bank" required>
                                        <option selected>Pilih</option>
                                        <option value="Bank BSI" @if($row->pilihan_bank == 'Bank BSI') selected @endif>Bank BSI</option>
                                        <option value="Bank BRI" @if($row->pilihan_bank == 'Bank BRI') selected @endif>Bank BRI</option>
                                        <option value="Bank BNI" @if($row->pilihan_bank == 'Bank BNI') selected @endif>Bank BNI</option>
                                        <option value="Bank BTN" @if($row->pilihan_bank == 'Bank BTN') selected @endif>Bank BTN</option>
                                        <option value="Bank Mandiri" @if($row->pilihan_bank == 'Bank Mandiri') selected @endif>Bank Mandiri</option>
                                        <option value="Bank BCA" @if($row->pilihan_bank == 'Bank BCA') selected @endif>Bank BCA</option>
                                        <option value="Bank Muamalat" @if($row->pilihan_bank == 'Bank Muamalat') selected @endif>Bank Muamalat</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Nomor Rekening</label>
                                    <input class="form-control" type="text" id="nomor_rekening" value="{{$row->nomor_rekening}}" name="nomor_rekening" placeholder="" required>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Nama Pemilik Rekening</label>
                                    <input class="form-control" type="text" id="nama_pemilik_rekening" value="{{$row->nama_pemilik_rekening}}" name="nama_pemilik_rekening" placeholder="" required>
                                </div>
                            </div><br>
                            <div class="py-0">
                                <h5>Transaksi</h5>
                            </div><hr>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Kode Transaksi</label>
                                    <input class="form-control" type="text" id="kode_transaksi" value="{{$row->kode_transaksi}}" name="kode_transaksi" placeholder="B.1234567.1.1" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jenis Transaksi</label>
                                    <input class="form-control" type="text" id="jenis_transaksi" value="{{$row->jenis_transaksi}}" name="jenis_transaksi" placeholder="Pengajuan Baru" readonly="">
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pilihan Jasa</label>
                                    <input class="form-control" type="text" id="pilihan_jasa" value="{{$row->pilihan_jasa}}"  name="pilihan_jasa" placeholder="Jasa diawal" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Perhitungan Jasa</label>
                                    <input class="form-control" type="text" id="perhitungan_jasa" value="{{$row->perhitungan_jasa}}" name="perhitungan_jasa" placeholder="Perhitungan Baru" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Jangka Waktu Permohonan</label>
                                    <select class="form-select" id="jangka_waktu_permohonan" name="jangka_waktu_permohonan" required>
                                        <option selected>Pilih</option>
                                        <option value="15 Hari" @if($row->jangka_waktu_permohonan == '15 Hari') selected @endif>15 Hari</option>
                                        <option value="1 Bulan" @if($row->jangka_waktu_permohonan == '1 Bulan') selected @endif>1 Bulan</option>
                                        <option value="2 Bulan" @if($row->jangka_waktu_permohonan == '2 Bulan') selected @endif>2 Bulan</option>
                                    </select>
                                </div>
                                
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jasa GTC(otomatis)</label>
                                    <input class="form-control" type="text" id="jasa_gtc" name="jasa_gtc" value="{{$row->jasa_gtc}}" placeholder="Rp 20.000" readonly>
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Pembayaran Jasa</label>
                                    <select class="form-select" id="pembayaran_jasa" name="pembayaran_jasa" required>
                                        <option selected>Pilih</option>
                                        <option value="Transfer" @if($row->pembayaran_jasa == 'Transfer') selected @endif>Transfer</option>
                                        <option value="Dipotong dari GTC" @if($row->pembayaran_jasa == 'Dipotong dari GTC') selected @endif>Dipotong dari GTC</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Buti Transfer(Jika transfer)</label>
                                    <input class="form-control" type="file" id="upload_bukti_transfer" value="{{$row->upload_bukti_transfer}}" name="upload_bukti_transfer">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pembayaran jasa(=Jasa GTC)Manual</label>
                                    <input class="form-control" type="text" id="pembayaran_jasa_manual" value="{{$row->pembayaran_jasa_manual}}" name="pembayaran_jasa_manual" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Ket. Simp.Wa</label>
                                    <select class="form-select" id="ket_simpwa" name="ket_simpwa" required>
                                        <option selected>Pilih</option>
                                        <option value="Lunas" @if($row->ket_simpwa = 'Lunas') selected @endif>Lunas</option>
                                        <option value="Dipotong dari GTC" @if($row->ket_simpwa = 'Dipotong dari GTC') selected @endif>Dipotong dari GTC</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Nominal Potongan(Jika dr GTC)</label>
                                    <input class="form-control" type="text" id="nominal_potongan" value="{{$row->nominal_potongan}}" name="nominal_potongan" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jumlah Yang di Transfer</label>
                                    <input class="form-control" type="text" id="jumlah_yang_di_transfer" value="{{$row->jumlah_yang_di_transfer}}" name="jumlah_yang_di_transfer" placeholder="Jumlah Yang di Transfer" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                            </div><br>
                            <div class="py-0">
                                <h5>Dokument</h5>
                            </div><hr>
                            <div class="row g-2">
                                <div class="col-md">
                                    <h5>Tipe Transaksi</h5>
                                    <div class="form-check">
                                        <input type="radio" id="tipe_transaksi" name="tipe_transaksi" class="form-check-input" value="Anggota Datang Langsung" @if($row->tipe_transaksi == 'Anggota Datang Langsung') checked @endif>
                                        <label class="form-check-label" for="customRadio1">Anggota Datang Langsung</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="tipe_transaksi" name="tipe_transaksi" class="form-check-input" value="Online" @if($row->tipe_transaksi == 'Online') checked @endif>
                                        <label class="form-check-label" for="customRadio2">Online</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Foto Gold</label>
                                    <input class="form-control" type="file" id="upload_foto_gold" value="{{$row->upload_foto_gold}}" name="upload_foto_gold"><br>
                                    <label for="formFile" class="form-label">Upload Form Pengajuan</label>
                                    <input class="form-control" type="file" id="upload_form_pengajuan" value="{{$row->upload_form_pengajuan}}" name="upload_form_pengajuan">
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Surat Terima Transfer(Tidak wajib)</label>
                                    <input class="form-control" type="file" id="upload_surat_terima_transfer" value="{{$row->upload_surat_terima_transfer}}" name="upload_surat_terima_transfer"><br>
                                    <label for="formFile" class="form-label">Surat Kuasa Penjualan Jaminan Marhun</label>
                                    <input class="form-control" type="file" id="surat_kuasa_penjualan_jaminan_marhum" value="{{$row->surat_kuasa_penjualan_jaminan_marhum}}" name="surat_kuasa_penjualan_jaminan_marhum">
                                </div>
                            </div><br>

                            <div class="card border-primary border">
                                <div class="card-body">
                                    <h5 class="card-title">Persetujuan : (jika Reguler)</h5>
                                    <p class="card-text">
                                        <ul class="ul-number">
                                            <li>
                                                 Simpanan berjangka dengan akad Mudharabah Muthlaqah
                                            </li>
                                            <li>
                                                Simpanan berjangka ini tidak dapat dicairkan sebelum tanggal jatuh tempo</li>
                                            <li>
                                                Simpanan Berjangka Dsyirkah minimal 100 Gram dengan jangka waktu 12 Bulan Mendapatkan Hadiah 1 Gram Gold / 100 Gram dengan jangka waktu 24 Bulan Mendapatkan Hadiah 2 Gram Gold
                                            </li>
                                            <li>
                                                Saya siap mengembalikan hadiah jika tidak sesuai dengan akad.
                                            </li>
                                        </ul>
                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div>

                        
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card border-secondary border">
                                    <div class="card-body">
                                        <h5 class="card-title">Catatan :</h5>
                                        <p class="card-text">Catatan Dari form pengajuan</p>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div>
                            <div class="col-lg-6">
                                <div class="card border-secondary border">
                                    <div class="card-body">
                                        <h5 class="card-title">Tandatangan :</h5>
                                        <p class="card-text">Tandtangan Dari Form</p>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div>
                        </div>
                        <br><div class="mb-3 text-center" >
                            <button class="btn btn-primary" id="btnaddpengajuan" type="submit"> Simpan </button>
                        </div>
                    </form>
                    @endforeach
                </div>
                
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->


<!-- Modal view-->
<div class="modal fade" id="modal-view-pemohon" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">View Data CIF Anggota</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                @foreach($data as $row)
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor Buku Anggota</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_nomor_buku_anggota"><strong>: {{$row->nomor_ba}}</strong> </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nama Lengkap</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nama_lengkap"><strong>: </strong>{{$row->nama_lengkap}}</h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor Hp</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nomor_hp"><strong>: </strong>{{$row->no_hp}}</h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Email</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_email"><strong>: </strong>{{$row->email}}</h>
                    </div><hr>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor KTP</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nomor_ktp"><strong>: </strong>{{$row->no_ktp}}</h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Jenis Kelamin</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_jenis_kelamin"><strong>: </strong>{{$row->jenis_kelamin}}</h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Tempat Lahir</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_tempat_lahir"><strong>: </strong>{{$row->tempat_lahir}}</h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Tanggal Lahir</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_tanggal_lahir"><strong>: </strong>{{$row->tanggal_lahir}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Status Pernikahan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_status_pernikahan"><strong>: </strong>{{$row->status_nikah}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor NPWP</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_nomor_npwp"><strong>: </strong>{{$row->no_npwp}}</p>
                    </div><hr>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Sesuai KTP</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_sesuai_ktp"><strong>: </strong>{{$row->alamat_ktp}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kecamatan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kecamatan"><strong>: </strong>{{$row->kecamatan_ktp}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kota_kabupaten"><strong>: </strong>{{$row->kota_ktp}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Provinsi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_provinsi"><strong>: </strong>{{$row->provinsi_ktp}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Tinggal</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_tinggal"><strong>: </strong>{{$row->alamat_tinggal}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Tinggal Saat ini</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_tinggal_domisili"><strong>: </strong>{{$row->alamat_domisili}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kecamatan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kecamatan_domisili"><strong>: </strong>{{$row->kecamatan_domisili}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kota_kabupaten_domisili"><strong>: </strong>{{$row->kota_domisili}}</p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Provinsi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_provinsi_domisili"><strong>: </strong>{{$row->provinsi_domisili}}</p>
                    </div><hr>
                </div>
                <div class="col-4">
                    <p class="font-14" id="detail_photo_ktp"><strong>{{$row->foto_ktp}}</strong></p>
                </div>
                <!-- <img src="assets/images/small/small-2.jpg" alt="image" class="img-fluid rounded" width="600"/> -->
                @endforeach
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-tambah-datacif" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Tambah Data CIF Anggota</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                @foreach($data as $row)
                <form id="formtambahdatacifanggota" method="post">
                @csrf
                    <input type="hidden" name="_method" value="put">
                    <h5>Data Akun</h5><hr>
                    <div class="row g-2">
                        <div class="col-md">
                            <label class="form-label">Nomor BA</label>
                            <input type="hidden" class="form-control" value="{{$row->id_anggota}}" id="tambah_id_anggota" name="tambah_id_anggota" readonly>
                            <div class="input-group">
                                <input type="text" class="form-control" value="{{$row->nomor_ba}}" id="tambah_nomor_ba" name="tambah_nomor_ba" placeholder="Cari Nomor BA" readonly>
                            </div>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nama Lengkap</label>
                            <input class="form-control" type="text" value="{{$row->nama_lengkap}}" id="tambah_nama_lengkap" name="tambah_nama_lengkap" placeholder="Enter your name" readonly>
                        </div>
                    </div><br>
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor HP</label>
                            <input class="form-control" type="text" value="{{$row->no_hp}}" id="tambah_nomor_hp" name="tambah_nomor_hp" placeholder="0994538574985" readonly="">
                        </div>
                        <div class="col-md">
                            <label for="emailaddress" class="form-label">Email address</label>
                            <input class="form-control" type="email" value="{{$row->email}}" id="tambah_email" name="tambah_email" placeholder="Email" readonly=""> 
                        </div>
                    </div><hr><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor KTP</label>
                            <input class="form-control" type="text" value="{{$row->no_ktp}}" id="tambah_nomor_ktp" name="tambah_nomor_ktp" placeholder="0123123456788123" data-toggle="input-mask" data-mask-format="0000000000000000" required>
                        </div>
                        <div class="col-md">
                            <label for="example-select" class="form-label">Jenis Kelamin</label>
                            <select class="form-select" id="tambah_jenis_kelamin" name="tambah_jenis_kelamin" required>
                                <option selected>Pilih</option>
                                <option value="Laki-laki" @if($row->jenis_kelamin == 'Laki-laki') selected @endif>Laki - Laki</option>
                                <option value="Perempuan" @if($row->jenis_kelamin == 'Perempuan') selected @endif>Perempuan</option>
                            </select>
                        </div>
                    </div><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Tempat Lahir</label>
                            <input class="form-control" type="text" value="{{$row->tempat_lahir}}" id="tambah_tempat_lahir" name="tambah_tempat_lahir" placeholder="Enter your name" required>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Tanggal Lahir</label>
                            <input class="form-control date" type="date" value="{{$row->tanggal_lahir}}" id="tambah_tanggal_lahir" name="tambah_tanggal_lahir" placeholder="dd/mm/yyyy" required>
                        </div>
                    </div><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="example-select" class="form-label">Status Pernikahan</label>
                            <select class="form-select" id="tambah_status_pernikahan" name="tambah_status_pernikahan" required>
                                <option selected>Pilih</option>
                                <option value="Sudah Nikah" @if($row->status_nikah == 'Sudah Nikah') selected @endif>Sudah Nikah</option>
                                <option value="Belum Nikah" @if($row->status_nikah == 'Belum Nikah') selected @endif>Belum Nikah</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor NPWP (Jika Punya)</label>
                            <input class="form-control date" type="text" value="{{$row->no_npwp}}" id="tambah_nomor_npwp" name="tambah_nomor_npwp" placeholder="000000000">
                        </div>
                    </div><hr><br>

                    <div class="col-md">
                        <label for="fullname" class="form-label">Alamat Sesuai KTP</label>
                        <input class="form-control date" type="text" value="{{$row->alamat_ktp}}" id="tambah_alamat_sesuai_ktp" name="tambah_alamat_sesuai_ktp" placeholder="Jl. Raya Nommor:00 RT/RW" required>
                    </div>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Provinsi</label>
                            <select class="form-control select2" id="provinsi" name="tambah_provinsi" name="tambah_provinsi" placeholder="dd/mm/yyyy">
                                <option>Provinsi</option>
                                <option>Data Masih Diproses</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kota / Kabupaten</label>
                            <select class="form-control" id="kota" name="tambah_kota" placeholder="Enter your name">
                                <option>Kabupaten/Kota</option>
                                <option>Pilih Provinsi Terlebih Dahulu</option>
                            </select>
                        </div>
                    </div><br>
                    
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kecamatan</label>
                            <select class="form-control" id="kecamatan" name="tambah_kecamatan" placeholder="dd/mm/yyyy">
                                <option>Kecamatan</option>
                                <option>Pilih Kota / Kabupaten Terlebih Dahulu</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kelurahan</label>
                            <select class="form-control" id="kelurahan" name="tambah_kelurahan" placeholder="Enter your name">
                                <option>Kelurahan</option>
                                <option>Pilih Kelurahan Terlebih Dahulu</option>
                            </select>
                        </div>
                    </div><br>

                    <div class="col-md">
                        <label for="example-select" class="form-label">Alamat Tinggal</label>
                        <input type="hidden" id="tambah_alamat_tinggal_hidden" value="{{$row->alamat_tinggal}}" name="">
                        <select class="form-select" id="tambah_alamat_tinggal" name="tambah_alamat_tinggal">
                            <option selected>Pilih</option>
                            <option id="sesuai_ktp" value="sesuai" @if($row->alamat_tinggal == 'sesuai') selected @endif>Sesuai KTP</option>
                            <option id="tidak_sesuai_ktp" value="tidakSesuai" @if($row->alamat_tinggal == 'tidakSesuai') selected @endif>Tidak Sesuai KTP</option>
                        </select>
                    </div><br>
                    <div class="" id="divtidaksesuaiktp" style="display: none;">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Alamat Saat Ini(domisili)</label>
                            <input class="form-control date" type="text" value="{{$row->alamat_domisili}}" id="tambah_alamat_domisili" name="tambah_alamat_domisili" placeholder="Jl. Raya Nommor:00 RT/RW">
                        </div>

                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Provinsi</label>
                                <select class="form-control select2" id="tambah_provinsi_domisili" name="tambah_provinsi_domisili" placeholder="dd/mm/yyyy">
                                    <option>Provinsi</option>
                                    <option>Data Masih Diproses</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kota / Kabupaten</label>
                                <select class="form-control" id="tambah_kota_kabupaten_domisili" name="tambah_kota_kabupaten_domisili" placeholder="Enter your name">
                                    <option>Kabupaten/Kota</option>
                                    <option>Pilih Provinsi Terlebih Dahulu</option>
                                </select>
                            </div>
                        </div><br>
                        
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kecamatan</label>
                                <select class="form-control" id="tambah_kecamatan_domisili" name="tambah_kecamatan_domisili" placeholder="dd/mm/yyyy">
                                    <option>Kecamatan</option>
                                    <option>Pilih Kota / Kabupaten Terlebih Dahulu</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kelurahan</label>
                                <select class="form-control" id="tambah_kelurahan_domisili" name="tambah_kelurahan_domisili" placeholder="Enter your name">
                                    <option>Kelurahan</option>
                                    <option>Pilih Kelurahan Terlebih Dahulu</option>
                                </select>
                            </div>
                            <input type="hidden" class="form-control" value="{{$row->provinsi_ktp}}" id="tambah_old_provinsi">
                            <input type="hidden" class="form-control" value="{{$row->kota_ktp}}" id="tambah_old_kota">
                            <input type="hidden" class="form-control" value="{{$row->kecamatan_ktp}}" id="tambah_old_kecamatan">
                            <input type="hidden" class="form-control" value="{{$row->kelurahan_ktp}}" id="tambah_old_kelurahan">
                            <input type="hidden" class="form-control" value="{{$row->provinsi_domisili}}" id="tambah_old_provinsi_domisili">
                            <input type="hidden" class="form-control" value="{{$row->kota_domisili}}" id="tambah_old_kota_domisili">
                            <input type="hidden" class="form-control" value="{{$row->kecamatan_domisili}}" id="tambah_old_kecamatan_domisili">
                            <input type="hidden" class="form-control" value="{{$row->kelurahan_domisili}}" id="tambah_old_kelurahan_domisili">
                        </div>
                        <hr><br>
                    </div>
                    <div class="mb-3">
                        <label for="formFile" class="form-label">Upload Foto KTP</label>
                        <input class="form-control" type="file" id="tambah_upload_foto_ktp" name="tambah_upload_foto_ktp">
                    </div><hr><br>

                    <br><div class="mb-3 text-center" >
                        <button class="btn btn-primary" type="submit" id="btntambahdatacifanggota"> Simpan </button>
                    </div>
                </form>
                @endforeach
                <h5>Histori Data</h5><hr>
                <table id="scroll-horizontal-datatable" class="table table-striped w-100 nowrap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor BA</th>
                            <th>Nama Lengkap</th>
                            <th>No HP</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>No KTP</th>
                            <th>Jenis Kelamin</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Status Nikah</th>
                            <th>No NPWP</th>
                            <th>Alamat KTP</th>
                            <th>Provinsi KTP</th>
                            <th>Kota KTP</th>
                            <th>Kecamatan KTP</th>
                            <th>Kelurahan KTP</th>
                            <th>Alamat Tinggal</th>
                            <th>Alamat Domisili</th>
                            <th>Provinsi Domisili</th>
                            <th>Kota Domisili</th>
                            <th>Kecamatan Domisili</th>
                            <th>Kelurahan Domisili</th>
                            <th>Updated_at</th>
                        </tr>
                    </thead>
                    <tbody id="bodyhistorianggota">
                    </tbody>
                </table>    
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="addemasgtc" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg loading authentication-bg">
        <div class="modal-content bg-transparent">
        <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-7 col-lg-5">
                        <div class="card">
                            <!-- Logo-->
                            <div class="modal-header" style="background-color: #afb4be">
                                <div style="color: rgb(255, 255, 255);"><h4 id="modalHeading">Tambah Item Emas</h4></div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                            </div>
                            <div class="card-body p-4">
                                <form id="formaddemasgtc" method="post">
                                @csrf
                                    @foreach($emas_syirkah as $emas)
                                    <div class="">
                                        <div class="col-md">
                                            <label for="" class="form-label">Item Emas</label>
                                            @foreach($data as $row)
                                            <input type="hidden" id="kode_pengajuan_emasgtc" name="kode_pengajuan_emasgtc" value="{{$row->kode_pengajuan}}" readonly>
                                            @endforeach
                                            <input type="text" class="form-control" id="item_emas" name="item_emas" value="{{$emas->nama}}" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Jenis</label>
                                            <input type="text" class="form-control" id="jenis" name="jenis" value="{{$emas->jenis}}" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Gramasi</label>
                                            <input type="text" class="form-control" id="gramasi" name="gramasi" value="{{$emas->gramasi}}" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Harga Buyback</label>
                                            @foreach($hargaharian as $item)
                                            <input type="hidden" value="{{$item->id}}" id="id_harga_buyback" name="id_harga_buyback" class="form-control">
                                            <select type="text" class="form-select" id="harga_buyback" name="harga_buyback">
                                                <option value="{{$item->nolsatu_gram}}">0.1 Gram</option>
                                                <!-- <option value="{{$item->noldua_gram}}">0.2 Gram</option>
                                                <option value="{{$item->nollima_gram}}">0.5 Gram</option>
                                                <option value="{{$item->satu_gram}}">1 Gram</option>
                                                <option value="{{$item->dua_gram}}">2 Gram</option>
                                                <option value="{{$item->lima_gram}}">5 Gram</option>
                                                <option value="{{$item->sepuluh_gram}}">10 Gram</option> -->
                                            </select>
                                            @endforeach
                                        </div><br>
                                        <div class="col-md">
                                            <button class="btn btn-warning" id="btnaddemasgtc" type="submit">Tambah</button>
                                        </div>
                                    </div>
                                    @endforeach
                                </form>
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>

                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        </div>
        <!-- end page -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
@endsection
@push('script')
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="{{asset('assets/plugins/select2/js/select2.min.js')}}"></script>
<script src="{{asset('customjs/backend/edit_pengajuan_gtc.js')}}"></script>
<script src="{{asset('customjs/backend/loading.js')}}"></script>
@endpush