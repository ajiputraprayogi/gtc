<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <?php echo $__env->yieldContent('token'); ?>
    <?php
    $websetting = DB::table('settings')->orderby('id','desc')->limit(1)->get();
    ?>
    <?php $__currentLoopData = $websetting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_websetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <title><?php echo e($row_websetting->singkatan_nama_program); ?></title>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/plugins/fontawesome-free/css/all.min.css')); ?>">
    <?php echo $__env->yieldContent('customcss'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dist/css/adminlte.min.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>

<body class="hold-transition layout-top-nav">
    <div class="wrapper">
        <nav class="main-header navbar navbar-expand-md navbar-dark navbar-dark">
            <div class="container">
                <a href="<?php echo e(url('/backend/home')); ?>" class="navbar-brand">
                    <?php $__currentLoopData = $websetting; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row_websetting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <span class="brand-text font-weight-light"><?php echo e($row_websetting->singkatan_nama_program); ?></span>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </a>

                <button class="navbar-toggler order-1" type="button" data-toggle="collapse"
                    data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false"
                    aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse order-3" id="navbarCollapse">
                    <?php echo $__env->make('layouts/nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <ul class="order-1 order-md-3 navbar-nav navbar-no-expand ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link" data-toggle="dropdown" href="#">
                            <i class="far fa-user-circle"></i> <?php echo e(Auth::user()->username); ?>

                        </a>
                        <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
                            <span class="dropdown-header">My Profile</span>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('editprofile')); ?>" class="dropdown-item">
                                Edit Profile
                            </a>
                            <div class="dropdown-divider"></div>
                            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"
                                class="dropdown-item">
                                Logout
                            </a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                <?php echo csrf_field(); ?>
                            </form>
                            <div class="dropdown-divider"></div>
                            <?php if(auth()->user()->can('setting-web')): ?>
                            <a href="<?php echo e(url('backend/web-setting')); ?>" class="dropdown-item">
                                Web Setting
                            </a>
                            <?php endif; ?>
                        </div>
                    </li>
                </ul>
            </div>
        </nav>
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

    </div>
    <script src="<?php echo e(asset('assets/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('customjs'); ?>
    <script src="<?php echo e(asset('assets/dist/js/adminlte.min.js')); ?>"></script>
    <?php echo $__env->yieldPushContent('customscripts'); ?>
</body>

</html><?php /**PATH D:\Kediri App\project\laravel\dboiler\dboilerlaravel-main\dboilerlaravel-main\resources\views/layouts/base.blade.php ENDPATH**/ ?>