
<?php $__env->startSection('css'); ?>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<link href="<?php echo e(asset('assets/plugins/select2/css/select2.min.css')); ?>" rel="stylesheet" />
<link rel="stylesheet" href="<?php echo e(asset('assets/plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('customjs/backend/loading.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- start page title -->
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <li class="breadcrumb-item"><a href="javascript: void(0);">Get The Cash</a></li>
                        <li class="breadcrumb-item active">Pengajuan GTC</li>
                    </ol>
                </div>
                <h4 class="page-title">Pengajuan GTC</h4>
            </div>
        </div>
    </div>
    <!-- end page title --> 


    <div class="row" id="panel">
        <div class="col-12">
            <div class="card d-block">
                <div class="card-header bg-secondary border-danger border-3" >
                    <div class=" align-items-center mb-2 text-white">
                        <h3>Form Pengajuan GTC</h3>
                    </div>
                </div>
                <div class="card-body">
                    <div class="py-0">
                        <h5>Data Pemohon</h5>
                    </div><hr>
                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $dataanggota = DB::table('anggota')->get();
                    ?>
                    <form action="<?php echo e(url('/backend/pengajuan-gtc')); ?>" id="formaddpengajuangtc" method="post">
                    <?php echo csrf_field(); ?>
                        <input type="hidden" name="_method" value="put">
                        <input type="hidden" name="id_pengajuan" id="id_pengajuan" value="<?php echo e($row->idp); ?>" class="form-control">
                        <div class="row g-2">
                            <div class="col-md">
                                <label class="form-label">Nomor BA</label>
                                <div class="input-group">
                                    <select type="text" class="form-control" id="nomor_ba" aria-label="Recipient's username">
                                        <?php $__currentLoopData = $dataanggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $anggota): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($anggota->id == $row->id_anggota): ?> selected <?php endif; ?>><?php echo e($row->nomor_ba); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <input type="hidden" class="form-control" value="<?php echo e($row->id_anggota); ?>" id="id_anggota" name="id_anggota">
                                </div>
                                <!-- <div class="input-group">
                                    <input type="text" class="form-control" placeholder="x.xxx.xxxxx23" aria-label="Recipient's username" readonly>
                                    <button class="btn btn-primary" type="button">Cari</button>
                                </div> -->
                                </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Nama Lengkap</label>
                                <input class="form-control" type="text" id="nama_lengkap" value="<?php echo e($row->nama_lengkap); ?>" placeholder="Nama Sesuai" readonly="">
                            </div>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Nomor HP</label>
                                <input class="form-control" type="text" id="no_hp" value="<?php echo e($row->no_hp); ?>" placeholder="xxxxxxxxxx985" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="emailaddress" class="form-label">Email address</label>
                                <input class="form-control" type="email" id="email" value="<?php echo e($row->email); ?>" placeholder="xxxxx788@gmail.com" readonly=""> 
                            </div>
                        </div><br>
                        <div class="row g-2">
                            <div class="col-6">
                            </div>
                            <div class="col-sm-6">
                                <a href="" class="btn btn-primary mb-2" data-bs-toggle="modal" data-bs-target="#modal-view-pemohon" id="detailpemohonbtn" style="display: show"><i class="mdi mdi-card-search-outline"></i> Detail Pemohon</a>
                                <a href="" class="btn btn-danger mb-2" data-bs-toggle="modal" data-bs-target="#modal-tambah-datacif" id="datacifanggotabtn"  style="display: show"><i class="mdi mdi-plus-circle me-2"></i> Data CIF Anggota</a>
                            </div><br>
                        </div>
                        <div class="py-0">
                            <h5>Data Pengajuan</h5>
                        </div><hr>
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Perwada (sesuai dg Akun)</label>
                                <input class="form-control" type="text" id="perwada" value="KP Jakarta" placeholder="KP Jakarta" readonly="">
                                <input type="hidden" value="<?php echo e($row->id_perwada); ?>" id="id_perwada" name="id_perwada" class="form-control">
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kode Pengajuan</label>
                                <input class="form-control" type="text" id="kode_pengajuan" value="<?php echo e($row->kode_pengajuan); ?>" name="kode_pengajuan" placeholder="Create by System" readonly="">
                            </div>
                            <div class="col-md">
                                <label for="example-select" class="form-label">Tujuan</label>
                                <select class="form-select" id="tujuan" name="tujuan" required>
                                    <option selected>Pilih</option>
                                    <option value="Untuk Modal Usaha" <?php if($row->tujuan == 'Untuk Modal Usaha'): ?> selected <?php endif; ?>>Untuk Modal Usaha</option>
                                    <option value="Biaya Pendidikan" <?php if($row->tujuan == 'Biaya Pendidikan'): ?> selected <?php endif; ?>>Biaya Pendidikan</option>
                                    <option value="Investasi" <?php if($row->tujuan == 'Investasi'): ?> selected <?php endif; ?>>Investasi</option>
                                    <option value="Pembelian Barang" <?php if($row->tujuan == 'Pembelian Barang'): ?> selected <?php endif; ?>>Pembelian Barang</option>
                                    <option value="Lainnya" <?php if($row->tujuan == 'Lainnya'): ?> selected <?php endif; ?>>Lainnya</option>
                                </select>
                            </div>
                        </div><hr><br>

                        <div class="col-lg-12">
                            <div class="col-sm-5">
                                <a id="btnmodaladdemasgtc" href="javascript:void(0);" class="btn mb-2 text-white bg-primary" data-bs-toggle="modal" data-bs-target="#addemasgtc" style="display: show"><i class="mdi mdi-plus-circle me-2"></i> Emas GTC</a>
                            </div>
                            <div class="table-responsive">
                                <table class="table table-borderless table-nowrap table-centered mb-0">
                                    <thead class="text-white bg-secondary ">
                                        <tr>
                                            <th>Item emas</th>
                                            <th>Jenis</th>
                                            <th>Gramasi</th>
                                            <th>Harga Buyback</th> 
                                            <th>Keping</th>
                                            <th>Jumlah Gramasi</th>
                                            <th>Jumlah Buyback</th>
                                            <th style="width: 50px;"></th>
                                        </tr>
                                    </thead>
                                    <tfoot id="footemasgtc" class="text-white bg-secondary ">
                                        <!-- <tr>
                                            <th>Total</th>
                                            <th></th>
                                            <th></th>
                                            <th></th>
                                            <th id="total_keping">0</th>
                                            <th id="total_gramasi">0</th>
                                            <th id="total_buyback">0</th>
                                            <th style="width: 50px;"></th>
                                        </tr> -->
                                    </tfoot>
                                    <tbody id="bodyemasgtc">
                                        <!-- <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td class="gramasi">0.1</td>
                                            <td class="harga_buyback">150000</td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a href="javascript:void(0);" class="action-icon"> <i
                                                        class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>Gold 0.1 Gram</td>
                                            <td>
                                                <span class="badge badge-primary-lighten">Reguler</span>
                                            </td>
                                            <td class="gramasi">0.2</td>
                                            <td class="harga_buyback">300000</td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a href="javascript:void(0);" class="action-icon"> <i
                                                        class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr> -->
                                        <!-- <?php $__currentLoopData = $emas_gtc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->item_emas); ?></td>
                                            <td>
                                                <span class="badge badge-primary-lighten"><?php echo e($item->jenis); ?></span>
                                            </td>
                                            <td class="gramasi"><?php echo e($item->gramasi); ?></td>
                                            <td class="harga_buyback"><?php echo e($item->harga_buyback); ?></td>
                                            <td hidden class="harga_buyback_hidden"><?php echo e($item->harga_buyback); ?></td>
                                            <td>
                                                <input type="" min="1" value="" class="keping"
                                                    placeholder="Qty" style="width: 90px;">
                                            </td>
                                            <td class="jumlah_gramasi">0</td>
                                            <td class="jumlah_buyback">0</td>
                                            <td hidden class="jumlah_buyback_hidden">0</td>
                                            <td>
                                                <a onclick="hapusdataemasgtc(<?php echo e($item->id); ?>)" class="action-icon"> <i class="mdi mdi-delete"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
                                    </tbody>
                                </table>
                            </div><hr><br> <!-- end table-responsive-->

                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Plafond Pinjaman</label>
                                    <input class="form-control" type="text" id="plafond_pinjaman" value="<?php echo e($row->plafond_pinjaman); ?>" name="plafond_pinjaman" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required readonly>
                                    <!-- <input type="text" class="form-control" id="plafond_pinjaman_hidden"> -->
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pengajuan</label>
                                    <input class="form-control" type="text" id="pengajuan" name="pengajuan" value="<?php echo e($row->pengajuan); ?>" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                    <!-- <input type="text" class="form-control" id="pengajuan_hidden"> -->
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Pilihan Bank</label>
                                    <select class="form-select" id="pilihan_bank" name="pilihan_bank" required>
                                        <option selected>Pilih</option>
                                        <option value="Bank BSI" <?php if($row->pilihan_bank == 'Bank BSI'): ?> selected <?php endif; ?>>Bank BSI</option>
                                        <option value="Bank BRI" <?php if($row->pilihan_bank == 'Bank BRI'): ?> selected <?php endif; ?>>Bank BRI</option>
                                        <option value="Bank BNI" <?php if($row->pilihan_bank == 'Bank BNI'): ?> selected <?php endif; ?>>Bank BNI</option>
                                        <option value="Bank BTN" <?php if($row->pilihan_bank == 'Bank BTN'): ?> selected <?php endif; ?>>Bank BTN</option>
                                        <option value="Bank Mandiri" <?php if($row->pilihan_bank == 'Bank Mandiri'): ?> selected <?php endif; ?>>Bank Mandiri</option>
                                        <option value="Bank BCA" <?php if($row->pilihan_bank == 'Bank BCA'): ?> selected <?php endif; ?>>Bank BCA</option>
                                        <option value="Bank Muamalat" <?php if($row->pilihan_bank == 'Bank Muamalat'): ?> selected <?php endif; ?>>Bank Muamalat</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Nomor Rekening</label>
                                    <input class="form-control" type="text" id="nomor_rekening" value="<?php echo e($row->nomor_rekening); ?>" name="nomor_rekening" placeholder="" required>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Nama Pemilik Rekening</label>
                                    <input class="form-control" type="text" id="nama_pemilik_rekening" value="<?php echo e($row->nama_pemilik_rekening); ?>" name="nama_pemilik_rekening" placeholder="" required>
                                </div>
                            </div><br>
                            <div class="py-0">
                                <h5>Transaksi</h5>
                            </div><hr>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Kode Transaksi</label>
                                    <input class="form-control" type="text" id="kode_transaksi" value="<?php echo e($row->kode_transaksi); ?>" name="kode_transaksi" placeholder="B.1234567.1.1" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jenis Transaksi</label>
                                    <input class="form-control" type="text" id="jenis_transaksi" value="<?php echo e($row->jenis_transaksi); ?>" name="jenis_transaksi" placeholder="Pengajuan Baru" readonly="">
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pilihan Jasa</label>
                                    <input class="form-control" type="text" id="pilihan_jasa" value="<?php echo e($row->pilihan_jasa); ?>"  name="pilihan_jasa" placeholder="Jasa diawal" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Perhitungan Jasa</label>
                                    <input class="form-control" type="text" id="perhitungan_jasa" value="<?php echo e($row->perhitungan_jasa); ?>" name="perhitungan_jasa" placeholder="Perhitungan Baru" readonly="">
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Jangka Waktu Permohonan</label>
                                    <select class="form-select" id="jangka_waktu_permohonan" name="jangka_waktu_permohonan" required>
                                        <option selected>Pilih</option>
                                        <option value="15 Hari" <?php if($row->jangka_waktu_permohonan == '15 Hari'): ?> selected <?php endif; ?>>15 Hari</option>
                                        <option value="1 Bulan" <?php if($row->jangka_waktu_permohonan == '1 Bulan'): ?> selected <?php endif; ?>>1 Bulan</option>
                                        <option value="2 Bulan" <?php if($row->jangka_waktu_permohonan == '2 Bulan'): ?> selected <?php endif; ?>>2 Bulan</option>
                                    </select>
                                </div>
                                
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jasa GTC(otomatis)</label>
                                    <input class="form-control" type="text" id="jasa_gtc" name="jasa_gtc" value="<?php echo e($row->jasa_gtc); ?>" placeholder="Rp 20.000" readonly>
                                </div>
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Pembayaran Jasa</label>
                                    <select class="form-select" id="pembayaran_jasa" name="pembayaran_jasa" required>
                                        <option selected>Pilih</option>
                                        <option value="Transfer" <?php if($row->pembayaran_jasa == 'Transfer'): ?> selected <?php endif; ?>>Transfer</option>
                                        <option value="Dipotong dari GTC" <?php if($row->pembayaran_jasa == 'Dipotong dari GTC'): ?> selected <?php endif; ?>>Dipotong dari GTC</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Buti Transfer(Jika transfer)</label>
                                    <input class="form-control" type="file" id="upload_bukti_transfer" value="<?php echo e($row->upload_bukti_transfer); ?>" name="upload_bukti_transfer">
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Pembayaran jasa(=Jasa GTC)Manual</label>
                                    <input class="form-control" type="text" id="pembayaran_jasa_manual" value="<?php echo e($row->pembayaran_jasa_manual); ?>" name="pembayaran_jasa_manual" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                            </div><br>
                            <div class="row g-2">
                                <div class="col-md">
                                    <label for="example-select" class="form-label">Ket. Simp.Wa</label>
                                    <select class="form-select" id="ket_simpwa" name="ket_simpwa" required>
                                        <option selected>Pilih</option>
                                        <option value="Lunas" <?php if($row->ket_simpwa = 'Lunas'): ?> selected <?php endif; ?>>Lunas</option>
                                        <option value="Dipotong dari GTC" <?php if($row->ket_simpwa = 'Dipotong dari GTC'): ?> selected <?php endif; ?>>Dipotong dari GTC</option>
                                    </select>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Nominal Potongan(Jika dr GTC)</label>
                                    <input class="form-control" type="text" id="nominal_potongan" value="<?php echo e($row->nominal_potongan); ?>" name="nominal_potongan" placeholder="000.000" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                                <div class="col-md">
                                    <label for="fullname" class="form-label">Jumlah Yang di Transfer</label>
                                    <input class="form-control" type="text" id="jumlah_yang_di_transfer" value="<?php echo e($row->jumlah_yang_di_transfer); ?>" name="jumlah_yang_di_transfer" placeholder="Jumlah Yang di Transfer" data-toggle="input-mask" data-mask-format="000.000.000.000.000" data-reverse="true" required>
                                </div>
                            </div><br>
                            <div class="py-0">
                                <h5>Dokument</h5>
                            </div><hr>
                            <div class="row g-2">
                                <div class="col-md">
                                    <h5>Tipe Transaksi</h5>
                                    <div class="form-check">
                                        <input type="radio" id="tipe_transaksi" name="tipe_transaksi" class="form-check-input" value="Anggota Datang Langsung" <?php if($row->tipe_transaksi == 'Anggota Datang Langsung'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="customRadio1">Anggota Datang Langsung</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" id="tipe_transaksi" name="tipe_transaksi" class="form-check-input" value="Online" <?php if($row->tipe_transaksi == 'Online'): ?> checked <?php endif; ?>>
                                        <label class="form-check-label" for="customRadio2">Online</label>
                                    </div>
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Foto Gold</label>
                                    <input class="form-control" type="file" id="upload_foto_gold" value="<?php echo e($row->upload_foto_gold); ?>" name="upload_foto_gold"><br>
                                    <label for="formFile" class="form-label">Upload Form Pengajuan</label>
                                    <input class="form-control" type="file" id="upload_form_pengajuan" value="<?php echo e($row->upload_form_pengajuan); ?>" name="upload_form_pengajuan">
                                </div>
                                <div class="col-md">
                                    <label for="formFile" class="form-label">Upload Surat Terima Transfer(Tidak wajib)</label>
                                    <input class="form-control" type="file" id="upload_surat_terima_transfer" value="<?php echo e($row->upload_surat_terima_transfer); ?>" name="upload_surat_terima_transfer"><br>
                                    <label for="formFile" class="form-label">Surat Kuasa Penjualan Jaminan Marhun</label>
                                    <input class="form-control" type="file" id="surat_kuasa_penjualan_jaminan_marhum" value="<?php echo e($row->surat_kuasa_penjualan_jaminan_marhum); ?>" name="surat_kuasa_penjualan_jaminan_marhum">
                                </div>
                            </div><br>

                            <div class="card border-primary border">
                                <div class="card-body">
                                    <h5 class="card-title">Persetujuan : (jika Reguler)</h5>
                                    <p class="card-text">
                                        <ul class="ul-number">
                                            <li>
                                                 Simpanan berjangka dengan akad Mudharabah Muthlaqah
                                            </li>
                                            <li>
                                                Simpanan berjangka ini tidak dapat dicairkan sebelum tanggal jatuh tempo</li>
                                            <li>
                                                Simpanan Berjangka Dsyirkah minimal 100 Gram dengan jangka waktu 12 Bulan Mendapatkan Hadiah 1 Gram Gold / 100 Gram dengan jangka waktu 24 Bulan Mendapatkan Hadiah 2 Gram Gold
                                            </li>
                                            <li>
                                                Saya siap mengembalikan hadiah jika tidak sesuai dengan akad.
                                            </li>
                                        </ul>
                                </div> <!-- end card-body-->
                            </div> <!-- end card-->
                        </div>

                        
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="card border-secondary border">
                                    <div class="card-body">
                                        <h5 class="card-title">Catatan :</h5>
                                        <p class="card-text">Catatan Dari form pengajuan</p>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div>
                            <div class="col-lg-6">
                                <div class="card border-secondary border">
                                    <div class="card-body">
                                        <h5 class="card-title">Tandatangan :</h5>
                                        <p class="card-text">Tandtangan Dari Form</p>
                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div>
                        </div>
                        <br><div class="mb-3 text-center" >
                            <button class="btn btn-primary" id="btnaddpengajuan" type="submit"> Simpan </button>
                        </div>
                    </form>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                
            </div>
        </div> <!-- end col -->
    </div>
    <!-- end row -->


<!-- Modal view-->
<div class="modal fade" id="modal-view-pemohon" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document"">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">View Data CIF Anggota</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor Buku Anggota</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_nomor_buku_anggota"><strong>: <?php echo e($row->nomor_ba); ?></strong> </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nama Lengkap</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nama_lengkap"><strong>: </strong><?php echo e($row->nama_lengkap); ?></h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor Hp</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nomor_hp"><strong>: </strong><?php echo e($row->no_hp); ?></h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Email</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_email"><strong>: </strong><?php echo e($row->email); ?></h>
                    </div><hr>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor KTP</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_nomor_ktp"><strong>: </strong><?php echo e($row->no_ktp); ?></h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Jenis Kelamin</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_jenis_kelamin"><strong>: </strong><?php echo e($row->jenis_kelamin); ?></h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Tempat Lahir</strong></p>
                    </div>
                    <div class="col-8">
                        <h class="font-14" id="detail_tempat_lahir"><strong>: </strong><?php echo e($row->tempat_lahir); ?></h>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Tanggal Lahir</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_tanggal_lahir"><strong>: </strong><?php echo e($row->tanggal_lahir); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Status Pernikahan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_status_pernikahan"><strong>: </strong><?php echo e($row->status_nikah); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Nomor NPWP</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_nomor_npwp"><strong>: </strong><?php echo e($row->no_npwp); ?></p>
                    </div><hr>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Sesuai KTP</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_sesuai_ktp"><strong>: </strong><?php echo e($row->alamat_ktp); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kecamatan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kecamatan"><strong>: </strong><?php echo e($row->kecamatan_ktp); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kota_kabupaten"><strong>: </strong><?php echo e($row->kota_ktp); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Provinsi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_provinsi"><strong>: </strong><?php echo e($row->provinsi_ktp); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Tinggal</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_tinggal"><strong>: </strong><?php echo e($row->alamat_tinggal); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Alamat Tinggal Saat ini</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_alamat_tinggal_domisili"><strong>: </strong><?php echo e($row->alamat_domisili); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kecamatan</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kecamatan_domisili"><strong>: </strong><?php echo e($row->kecamatan_domisili); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Kota / Kabupaten</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_kota_kabupaten_domisili"><strong>: </strong><?php echo e($row->kota_domisili); ?></p>
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <p class="font-14"><strong>Provinsi</strong></p>
                    </div>
                    <div class="col-8">
                        <p class="font-14" id="detail_provinsi_domisili"><strong>: </strong><?php echo e($row->provinsi_domisili); ?></p>
                    </div><hr>
                </div>
                <div class="col-4">
                    <p class="font-14" id="detail_photo_ktp"><strong><?php echo e($row->foto_ktp); ?></strong></p>
                </div>
                <!-- <img src="assets/images/small/small-2.jpg" alt="image" class="img-fluid rounded" width="600"/> -->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="modal-tambah-datacif" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header" style="background-color: #afb4be">
                <h4 class="modal-title" style="color: rgb(255, 255, 255);" id="myLargeModalLabel">Tambah Data CIF Anggota</h4>
                <button type="button" class="btn-close"  data-bs-dismiss="modal" aria-hidden="true"></button>
            </div>
            <div class="modal-body">
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <form id="formtambahdatacifanggota" method="post">
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="_method" value="put">
                    <h5>Data Akun</h5><hr>
                    <div class="row g-2">
                        <div class="col-md">
                            <label class="form-label">Nomor BA</label>
                            <input type="hidden" class="form-control" value="<?php echo e($row->id_anggota); ?>" id="tambah_id_anggota" name="tambah_id_anggota" readonly>
                            <div class="input-group">
                                <input type="text" class="form-control" value="<?php echo e($row->nomor_ba); ?>" id="tambah_nomor_ba" name="tambah_nomor_ba" placeholder="Cari Nomor BA" readonly>
                            </div>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nama Lengkap</label>
                            <input class="form-control" type="text" value="<?php echo e($row->nama_lengkap); ?>" id="tambah_nama_lengkap" name="tambah_nama_lengkap" placeholder="Enter your name" readonly>
                        </div>
                    </div><br>
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor HP</label>
                            <input class="form-control" type="text" value="<?php echo e($row->no_hp); ?>" id="tambah_nomor_hp" name="tambah_nomor_hp" placeholder="0994538574985" readonly="">
                        </div>
                        <div class="col-md">
                            <label for="emailaddress" class="form-label">Email address</label>
                            <input class="form-control" type="email" value="<?php echo e($row->email); ?>" id="tambah_email" name="tambah_email" placeholder="Email" readonly=""> 
                        </div>
                    </div><hr><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor KTP</label>
                            <input class="form-control" type="text" value="<?php echo e($row->no_ktp); ?>" id="tambah_nomor_ktp" name="tambah_nomor_ktp" placeholder="0123123456788123" data-toggle="input-mask" data-mask-format="0000000000000000" required>
                        </div>
                        <div class="col-md">
                            <label for="example-select" class="form-label">Jenis Kelamin</label>
                            <select class="form-select" id="tambah_jenis_kelamin" name="tambah_jenis_kelamin" required>
                                <option selected>Pilih</option>
                                <option value="Laki-laki" <?php if($row->jenis_kelamin == 'Laki-laki'): ?> selected <?php endif; ?>>Laki - Laki</option>
                                <option value="Perempuan" <?php if($row->jenis_kelamin == 'Perempuan'): ?> selected <?php endif; ?>>Perempuan</option>
                            </select>
                        </div>
                    </div><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Tempat Lahir</label>
                            <input class="form-control" type="text" value="<?php echo e($row->tempat_lahir); ?>" id="tambah_tempat_lahir" name="tambah_tempat_lahir" placeholder="Enter your name" required>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Tanggal Lahir</label>
                            <input class="form-control date" type="date" value="<?php echo e($row->tanggal_lahir); ?>" id="tambah_tanggal_lahir" name="tambah_tanggal_lahir" placeholder="dd/mm/yyyy" required>
                        </div>
                    </div><br>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="example-select" class="form-label">Status Pernikahan</label>
                            <select class="form-select" id="tambah_status_pernikahan" name="tambah_status_pernikahan" required>
                                <option selected>Pilih</option>
                                <option value="Sudah Nikah" <?php if($row->status_nikah == 'Sudah Nikah'): ?> selected <?php endif; ?>>Sudah Nikah</option>
                                <option value="Belum Nikah" <?php if($row->status_nikah == 'Belum Nikah'): ?> selected <?php endif; ?>>Belum Nikah</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Nomor NPWP (Jika Punya)</label>
                            <input class="form-control date" type="text" value="<?php echo e($row->no_npwp); ?>" id="tambah_nomor_npwp" name="tambah_nomor_npwp" placeholder="000000000">
                        </div>
                    </div><hr><br>

                    <div class="col-md">
                        <label for="fullname" class="form-label">Alamat Sesuai KTP</label>
                        <input class="form-control date" type="text" value="<?php echo e($row->alamat_ktp); ?>" id="tambah_alamat_sesuai_ktp" name="tambah_alamat_sesuai_ktp" placeholder="Jl. Raya Nommor:00 RT/RW" required>
                    </div>

                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Provinsi</label>
                            <select class="form-control select2" id="provinsi" name="tambah_provinsi" name="tambah_provinsi" placeholder="dd/mm/yyyy">
                                <option>Provinsi</option>
                                <option>Data Masih Diproses</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kota / Kabupaten</label>
                            <select class="form-control" id="kota" name="tambah_kota" placeholder="Enter your name">
                                <option>Kabupaten/Kota</option>
                                <option>Pilih Provinsi Terlebih Dahulu</option>
                            </select>
                        </div>
                    </div><br>
                    
                    <div class="row g-2">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kecamatan</label>
                            <select class="form-control" id="kecamatan" name="tambah_kecamatan" placeholder="dd/mm/yyyy">
                                <option>Kecamatan</option>
                                <option>Pilih Kota / Kabupaten Terlebih Dahulu</option>
                            </select>
                        </div>
                        <div class="col-md">
                            <label for="fullname" class="form-label">Kelurahan</label>
                            <select class="form-control" id="kelurahan" name="tambah_kelurahan" placeholder="Enter your name">
                                <option>Kelurahan</option>
                                <option>Pilih Kelurahan Terlebih Dahulu</option>
                            </select>
                        </div>
                    </div><br>

                    <div class="col-md">
                        <label for="example-select" class="form-label">Alamat Tinggal</label>
                        <input type="hidden" id="tambah_alamat_tinggal_hidden" value="<?php echo e($row->alamat_tinggal); ?>" name="">
                        <select class="form-select" id="tambah_alamat_tinggal" name="tambah_alamat_tinggal">
                            <option selected>Pilih</option>
                            <option id="sesuai_ktp" value="sesuai" <?php if($row->alamat_tinggal == 'sesuai'): ?> selected <?php endif; ?>>Sesuai KTP</option>
                            <option id="tidak_sesuai_ktp" value="tidakSesuai" <?php if($row->alamat_tinggal == 'tidakSesuai'): ?> selected <?php endif; ?>>Tidak Sesuai KTP</option>
                        </select>
                    </div><br>
                    <div class="" id="divtidaksesuaiktp" style="display: none;">
                        <div class="col-md">
                            <label for="fullname" class="form-label">Alamat Saat Ini(domisili)</label>
                            <input class="form-control date" type="text" value="<?php echo e($row->alamat_domisili); ?>" id="tambah_alamat_domisili" name="tambah_alamat_domisili" placeholder="Jl. Raya Nommor:00 RT/RW">
                        </div>

                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Provinsi</label>
                                <select class="form-control select2" id="tambah_provinsi_domisili" name="tambah_provinsi_domisili" placeholder="dd/mm/yyyy">
                                    <option>Provinsi</option>
                                    <option>Data Masih Diproses</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kota / Kabupaten</label>
                                <select class="form-control" id="tambah_kota_kabupaten_domisili" name="tambah_kota_kabupaten_domisili" placeholder="Enter your name">
                                    <option>Kabupaten/Kota</option>
                                    <option>Pilih Provinsi Terlebih Dahulu</option>
                                </select>
                            </div>
                        </div><br>
                        
                        <div class="row g-2">
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kecamatan</label>
                                <select class="form-control" id="tambah_kecamatan_domisili" name="tambah_kecamatan_domisili" placeholder="dd/mm/yyyy">
                                    <option>Kecamatan</option>
                                    <option>Pilih Kota / Kabupaten Terlebih Dahulu</option>
                                </select>
                            </div>
                            <div class="col-md">
                                <label for="fullname" class="form-label">Kelurahan</label>
                                <select class="form-control" id="tambah_kelurahan_domisili" name="tambah_kelurahan_domisili" placeholder="Enter your name">
                                    <option>Kelurahan</option>
                                    <option>Pilih Kelurahan Terlebih Dahulu</option>
                                </select>
                            </div>
                            <input type="hidden" class="form-control" value="<?php echo e($row->provinsi_ktp); ?>" id="tambah_old_provinsi">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kota_ktp); ?>" id="tambah_old_kota">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kecamatan_ktp); ?>" id="tambah_old_kecamatan">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kelurahan_ktp); ?>" id="tambah_old_kelurahan">
                            <input type="hidden" class="form-control" value="<?php echo e($row->provinsi_domisili); ?>" id="tambah_old_provinsi_domisili">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kota_domisili); ?>" id="tambah_old_kota_domisili">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kecamatan_domisili); ?>" id="tambah_old_kecamatan_domisili">
                            <input type="hidden" class="form-control" value="<?php echo e($row->kelurahan_domisili); ?>" id="tambah_old_kelurahan_domisili">
                        </div>
                        <hr><br>
                    </div>
                    <div class="mb-3">
                        <label for="formFile" class="form-label">Upload Foto KTP</label>
                        <input class="form-control" type="file" id="tambah_upload_foto_ktp" name="tambah_upload_foto_ktp">
                    </div><hr><br>

                    <br><div class="mb-3 text-center" >
                        <button class="btn btn-primary" type="submit" id="btntambahdatacifanggota"> Simpan </button>
                    </div>
                </form>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <h5>Histori Data</h5><hr>
                <table id="scroll-horizontal-datatable" class="table table-striped w-100 nowrap">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nomor BA</th>
                            <th>Nama Lengkap</th>
                            <th>No HP</th>
                            <th>Email</th>
                            <th>Status</th>
                            <th>No KTP</th>
                            <th>Jenis Kelamin</th>
                            <th>Tempat Lahir</th>
                            <th>Tanggal Lahir</th>
                            <th>Status Nikah</th>
                            <th>No NPWP</th>
                            <th>Alamat KTP</th>
                            <th>Provinsi KTP</th>
                            <th>Kota KTP</th>
                            <th>Kecamatan KTP</th>
                            <th>Kelurahan KTP</th>
                            <th>Alamat Tinggal</th>
                            <th>Alamat Domisili</th>
                            <th>Provinsi Domisili</th>
                            <th>Kota Domisili</th>
                            <th>Kecamatan Domisili</th>
                            <th>Kelurahan Domisili</th>
                            <th>Updated_at</th>
                        </tr>
                    </thead>
                    <tbody id="bodyhistorianggota">
                    </tbody>
                </table>    
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<div class="modal fade" id="addemasgtc" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg loading authentication-bg">
        <div class="modal-content bg-transparent">
        <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-xxl-7 col-lg-5">
                        <div class="card">
                            <!-- Logo-->
                            <div class="modal-header" style="background-color: #afb4be">
                                <div style="color: rgb(255, 255, 255);"><h4 id="modalHeading">Tambah Item Emas</h4></div>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-hidden="true"></button>
                            </div>
                            <div class="card-body p-4">
                                <form id="formaddemasgtc" method="post">
                                <?php echo csrf_field(); ?>
                                    <?php $__currentLoopData = $emas_syirkah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="">
                                        <div class="col-md">
                                            <label for="" class="form-label">Item Emas</label>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" id="kode_pengajuan_emasgtc" name="kode_pengajuan_emasgtc" value="<?php echo e($row->kode_pengajuan); ?>" readonly>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <input type="text" class="form-control" id="item_emas" name="item_emas" value="<?php echo e($emas->nama); ?>" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Jenis</label>
                                            <input type="text" class="form-control" id="jenis" name="jenis" value="<?php echo e($emas->jenis); ?>" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Gramasi</label>
                                            <input type="text" class="form-control" id="gramasi" name="gramasi" value="<?php echo e($emas->gramasi); ?>" readonly>
                                        </div>
                                        <div class="col-md">
                                            <label for="" class="form-label">Harga Buyback</label>
                                            <?php $__currentLoopData = $hargaharian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <input type="hidden" value="<?php echo e($item->id); ?>" id="id_harga_buyback" name="id_harga_buyback" class="form-control">
                                            <select type="text" class="form-select" id="harga_buyback" name="harga_buyback">
                                                <option value="<?php echo e($item->nolsatu_gram); ?>">0.1 Gram</option>
                                                <!-- <option value="<?php echo e($item->noldua_gram); ?>">0.2 Gram</option>
                                                <option value="<?php echo e($item->nollima_gram); ?>">0.5 Gram</option>
                                                <option value="<?php echo e($item->satu_gram); ?>">1 Gram</option>
                                                <option value="<?php echo e($item->dua_gram); ?>">2 Gram</option>
                                                <option value="<?php echo e($item->lima_gram); ?>">5 Gram</option>
                                                <option value="<?php echo e($item->sepuluh_gram); ?>">10 Gram</option> -->
                                            </select>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div><br>
                                        <div class="col-md">
                                            <button class="btn btn-warning" id="btnaddemasgtc" type="submit">Tambah</button>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </form>
                            </div> <!-- end card-body -->
                        </div>
                        <!-- end card -->
                        <!-- end row -->

                    </div> <!-- end col -->
                </div>

                <!-- end row -->
            </div>
            <!-- end container -->
        </div>
        </div>
        <!-- end page -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="<?php echo e(asset('assets/plugins/select2/js/select2.min.js')); ?>"></script>
<script src="<?php echo e(asset('customjs/backend/edit_pengajuan_gtc.js')); ?>"></script>
<script src="<?php echo e(asset('customjs/backend/loading.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kediri App\project\laravel\gtc\resources\views/backend/pengajuan_gtc/edit-pengajuan-gtc.blade.php ENDPATH**/ ?>